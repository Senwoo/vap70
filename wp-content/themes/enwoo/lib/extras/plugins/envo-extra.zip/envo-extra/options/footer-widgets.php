<?php

if (!class_exists('Kirki')) {
    return;
}

Kirki::add_section('footer_widgets', array(
    'title' => esc_attr__('Footer Widgets', 'envo-extra'),
    'panel' => 'envo_theme_panel',
    'priority' => 45,
));
Kirki::add_field('envo_extra', array(
    'type' => 'radio-buttonset',
    'settings' => 'widgets-width',
    'label' => esc_attr__('Footer widgets columns', 'envo-extra'),
    'section' => 'footer_widgets',
    'default' => '25',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        '98' => '1',
        '49' => '2',
        '31.33333333' => '3',
        '23' => '4',
    ),
    'output' => array(
        array(
            'element' => '#content-footer-section .widget.col-md-3',
            'property' => 'width',
            'media_query' => '@media (min-width: 992px)',
            'units' => '%',
        ),
    ),
));

Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'footer_font_color',
    'label' => esc_attr__('Font', 'envo-extra'),
    'section' => 'footer_widgets',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'variant' => '400',
        'letter-spacing' => '0px',
        'font-size' => '15px',
        'line-height' => '1.6',
        'text-transform' => 'none',
        'color' => '',
        'word-spacing' => '0px',
        'text-align' => 'none',
        'margin-top' => '5px',
        'margin-bottom' => '5px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '#content-footer-section .widget',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'footer_widget_title_color',
    'label' => esc_attr__('Widget Titles', 'envo-extra'),
    'section' => 'footer_widgets',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '15px',
        'variant' => '400',
        'line-height' => '1.6',
        'letter-spacing' => '0px',
        'color' => '',
        'text-transform' => 'none',
        'word-spacing' => '0px',
        'text-align' => 'none',
        'margin-top' => '5px',
        'margin-bottom' => '5px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '#content-footer-section .widget-title h3',
        )
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'color',
    'settings' => 'footer_bg_color',
    'label' => esc_attr__('Background', 'envo-extra'),
    'section' => 'footer_widgets',
    'default' => '',
    'transport' => 'auto',
    'priority' => 10,
    'output' => array(
        array(
            'element' => '#content-footer-section',
            'property' => 'background-color',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'multicolor',
    'settings' => 'footer_links_color',
    'label' => esc_attr__('Links', 'envo-extra'),
    'section' => 'footer_widgets',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'link' => esc_attr__('Color', 'envo-extra'),
        'hover' => esc_attr__('Hover', 'envo-extra'),
    ),
    'default' => array(
        'link' => '',
        'hover' => '',
    ),
    'output' => array(
        array(
            'choice' => 'link',
            'element' => '#content-footer-section a',
            'property' => 'color',
        ),
        array(
            'choice' => 'hover',
            'element' => '#content-footer-section a:hover',
            'property' => 'color',
        ),
    ),
));

Kirki::add_field('envo_extra', array(
    'settings' => 'footer_sidebar_border',
    'type' => 'border',
    'label' => esc_html__('Footer widgets area border', 'envo-extra'),
    'section' => 'footer_widgets',
    'transport' => 'auto',
    'choices' => array(
        'units' => array('px', 'em')
    ),
    'default' => array(
        'style' => 'none',
        'top' => 0,
        'bottom' => 0,
        'left' => 0,
        'right' => 0,
        'color' => '',
        'unit' => 'px'
    ),
    'output' => array(
        array(
            'element' => '#content-footer-section'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'settings' => 'footer_sidebar_box_shadow',
    'type' => 'box-shadow',
    'label' => esc_html__('Footer widgets area box shadow', 'envo-extra'),
    'section' => 'footer_widgets',
    'transport' => 'auto',
    'default' => array(
        'v_offset' => 0,
        'h_offset' => 0,
        'spread' => 0,
        'blur' => 0,
        'color' => ''
    ),
    'output' => array(
        array(
            'element' => '#content-footer-section'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'footer_sidebar_spacing',
    'label' => esc_attr__('Footer widgets spacing', 'envo-extra'),
    'section' => 'footer_widgets',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em', '%')
    ),
    'default' => array(
        'top' => '0',
        'right' => '0',
        'bottom' => '0',
        'left' => '0',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '#content-footer-section',
        ),
    ),
));

Kirki::add_field('envo_extra', array(
    'settings' => 'footer_widgets_border',
    'type' => 'border',
    'label' => esc_html__('Widgets border', 'envo-extra'),
    'section' => 'footer_widgets',
    'transport' => 'auto',
    'choices' => array(
        'units' => array('px', 'em')
    ),
    'default' => array(
        'style' => 'none',
        'top' => 0,
        'bottom' => 0,
        'left' => 0,
        'right' => 0,
        'color' => '',
        'unit' => 'px'
    ),
    'output' => array(
        array(
            'element' => '#content-footer-section .widget'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'settings' => 'footer_widgets_box_shadow',
    'type' => 'box-shadow',
    'label' => esc_html__('Widgets box shadow', 'envo-extra'),
    'section' => 'footer_widgets',
    'transport' => 'auto',
    'default' => array(
        'v_offset' => 0,
        'h_offset' => 0,
        'spread' => 0,
        'blur' => 0,
        'color' => ''
    ),
    'output' => array(
        array(
            'element' => '#content-footer-section .widget'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'footer_widgets_spacing',
    'label' => esc_attr__('Widgets spacing', 'envo-extra'),
    'section' => 'footer_widgets',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em', '%')
    ),
    'default' => array(
        'top' => '0',
        'right' => '0',
        'bottom' => '0',
        'left' => '0',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '#content-footer-section .widget',
        ),
    ),
));