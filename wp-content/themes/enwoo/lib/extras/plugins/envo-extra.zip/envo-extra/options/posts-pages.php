<?php

if (!class_exists('Kirki')) {
    return;
}

Kirki::add_section('blog_posts', array(
    'title' => esc_attr__('Blog posts archive', 'envo-extra'),
    'panel' => 'envo_theme_panel',
    'priority' => 25,
));

Kirki::add_section('posts_pages', array(
    'title' => esc_attr__('Single post and page', 'envo-extra'),
    'panel' => 'envo_theme_panel',
    'priority' => 30,
));


/**
 * Single post and page
 */
Kirki::add_field('envo_extra', array(
    'type' => 'sortable',
    'settings' => 'single_layout',
    'label' => esc_html__('Layout', 'kirki'),
    'section' => 'posts_pages',
    'default' => array(
        'image',
        'title',
        'meta',
        'content',
        'cats-tags',
        'nav'
    ),
    'choices' => array(
        'image' => esc_html__('Image', 'envo-extra'),
        'title' => esc_html__('Title', 'envo-extra'),
        'meta' => esc_html__('Meta', 'envo-extra'),
        'content' => esc_html__('Content', 'envo-extra'),
        'cats_tags' => esc_html__('Categories & Tags', 'envo-extra'),
        'nav' => esc_html__('Navigation', 'envo-extra'),
    ),
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'radio-buttonset',
    'settings' => 'posts_pages_date_single',
    'label' => esc_attr__('Meta Date', 'envo-extra'),
    'section' => 'posts_pages',
    'default' => 'inline-block',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'inline-block' => esc_attr__('Visible', 'envo-extra'),
        'none' => esc_attr__('Hidden', 'envo-extra'),
    ),
    'output' => array(
        array(
            'element' => '.single-post .posted-date',
            'property' => 'display',
        ),
    ),
    'active_callback' => array(
        array(
            'setting' => 'single_layout',
            'operator' => 'in',
            'value' => 'meta',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'radio-buttonset',
    'settings' => 'posts_pages_comments_single',
    'label' => esc_attr__('Meta comments', 'envo-extra'),
    'section' => 'posts_pages',
    'default' => 'inline-block',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'inline-block' => esc_attr__('Visible', 'envo-extra'),
        'none' => esc_attr__('Hidden', 'envo-extra'),
    ),
    'output' => array(
        array(
            'element' => '.single-post .comments-meta',
            'property' => 'display',
        ),
    ),
    'active_callback' => array(
        array(
            'setting' => 'single_layout',
            'operator' => 'in',
            'value' => 'meta',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'radio-buttonset',
    'settings' => 'posts_pages_author_single',
    'label' => esc_attr__('Meta Author', 'envo-extra'),
    'section' => 'posts_pages',
    'default' => 'inline-block',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'inline-block' => esc_attr__('Visible', 'envo-extra'),
        'none' => esc_attr__('Hidden', 'envo-extra'),
    ),
    'output' => array(
        array(
            'element' => '.single-post .author-meta',
            'property' => 'display',
        ),
    ),
    'active_callback' => array(
        array(
            'setting' => 'single_layout',
            'operator' => 'in',
            'value' => 'meta',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'posts_pages_title_font',
    'label' => esc_attr__('Title', 'envo-extra'),
    'section' => 'posts_pages',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'variant' => '',
        'letter-spacing' => '0px',
        'font-size' => '',
        'text-transform' => 'none',
        'color' => '',
        'text-align' => 'none',
        'margin-top' => '5px',
        'margin-bottom' => '5px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => 'h1.single-title',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'posts_pages_content_font',
    'label' => esc_attr__('Content font', 'envo-extra'),
    'section' => 'posts_pages',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'variant' => '',
        'letter-spacing' => '0px',
        'font-size' => '',
        'text-transform' => 'none',
        'color' => '',
        'line-height' => '',
        'word-spacing' => '0px',
        'text-align' => 'none',
        'margin-top' => '5px',
        'margin-bottom' => '5px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.single article .post, .page article .page, .single article .posted-date, .single .cat-links span, .single .tags-links span',
        ),
        array(
            'choice' => 'color',
            'property' => 'color',
            'element' => '.single span.comments-meta i',
        ),
    ),
));

Kirki::add_field('envo_extra', array(
    'settings' => 'single_border',
    'type' => 'border',
    'label' => esc_html__('Article border', 'envo-extra'),
    'section' => 'posts_pages',
    'transport' => 'auto',
    'choices' => array(
        'units' => array('px', 'em')
    ),
    'default' => array(
        'style' => 'none',
        'top' => 0,
        'bottom' => 0,
        'left' => 0,
        'right' => 0,
        'color' => '',
        'unit' => 'px'
    ),
    'output' => array(
        array(
            'element' => '.single-post-content'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'settings' => 'single_box_shadow',
    'type' => 'box-shadow',
    'label' => esc_html__('Article box shadow', 'envo-extra'),
    'section' => 'posts_pages',
    'transport' => 'auto',
    'default' => array(
        'v_offset' => 0,
        'h_offset' => 0,
        'spread' => 0,
        'blur' => 0,
        'color' => ''
    ),
    'output' => array(
        array(
            'element' => '.single-post-content'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'single_spacing',
    'label' => esc_attr__('Article spacing', 'envo-extra'),
    'section' => 'posts_pages',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em', '%')
    ),
    'default' => array(
        'top' => '0',
        'right' => '0',
        'bottom' => '0',
        'left' => '0',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '.single-post-content',
        ),
    ),
));

/**
 * Blog posts archive
 */
Kirki::add_field('envo_extra', array(
    'type' => 'sortable',
    'settings' => 'blog_layout',
    'label' => esc_html__('Layout', 'kirki'),
    'section' => 'blog_posts',
    'default' => array(
        'image',
        'title',
        'meta',
        'excerpt'
    ),
    'choices' => array(
        'image' => esc_html__('Image', 'kirki'),
        'title' => esc_html__('Title', 'kirki'),
        'meta' => esc_html__('Meta', 'kirki'),
        'excerpt' => esc_html__('Excerpt', 'kirki'),
    ),
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'radio-buttonset',
    'settings' => 'posts_pages_date',
    'label' => esc_attr__('Date', 'envo-extra'),
    'section' => 'blog_posts',
    'default' => 'inline-block',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'inline-block' => esc_attr__('Visible', 'envo-extra'),
        'none' => esc_attr__('Hidden', 'envo-extra'),
    ),
    'output' => array(
        array(
            'element' => '.news-item .posted-date',
            'property' => 'display',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'radio-buttonset',
    'settings' => 'posts_pages_comments',
    'label' => esc_attr__('Comments', 'envo-extra'),
    'section' => 'blog_posts',
    'default' => 'inline-block',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'inline-block' => esc_attr__('Visible', 'envo-extra'),
        'none' => esc_attr__('Hidden', 'envo-extra'),
    ),
    'output' => array(
        array(
            'element' => '.news-item .comments-meta',
            'property' => 'display',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'radio-buttonset',
    'settings' => 'posts_pages_author',
    'label' => esc_attr__('Author', 'envo-extra'),
    'section' => 'blog_posts',
    'default' => 'inline-block',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'inline-block' => esc_attr__('Visible', 'envo-extra'),
        'none' => esc_attr__('Hidden', 'envo-extra'),
    ),
    'output' => array(
        array(
            'element' => '.news-item .author-meta',
            'property' => 'display',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'blog_posts_title_font',
    'label' => esc_attr__('Title font', 'envo-extra'),
    'section' => 'blog_posts',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'variant' => '',
        'letter-spacing' => '0px',
        'font-size' => '',
        'text-transform' => 'none',
        'color' => '',
        'line-height' => '',
        'word-spacing' => '0px',
        'text-align' => 'none',
        'margin-top' => '5px',
        'margin-bottom' => '5px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.archive-item h2.entry-title a, .archive-item h2.entry-title',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'blog_posts_meta_font',
    'label' => esc_attr__('Meta font', 'envo-extra'),
    'section' => 'blog_posts',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'variant' => '',
        'letter-spacing' => '0px',
        'font-size' => '',
        'text-transform' => 'none',
        'color' => '',
        'line-height' => '',
        'word-spacing' => '0px',
        'text-align' => 'none',
        'margin-top' => '5px',
        'margin-bottom' => '5px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.archive-item .article-meta, .archive-item .posted-date, .archive-item .author-meta, .archive-item .comments-meta',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'blog_posts_content_font',
    'label' => esc_attr__('Excerpt font', 'envo-extra'),
    'section' => 'blog_posts',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'variant' => '',
        'letter-spacing' => '0px',
        'font-size' => '',
        'text-transform' => 'none',
        'color' => '',
        'line-height' => '',
        'word-spacing' => '0px',
        'text-align' => 'none',
        'margin-top' => '5px',
        'margin-bottom' => '5px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.archive-item .post-excerpt',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'slider',
    'settings' => 'blog_posts_excerpt_number_words',
    'label' => esc_attr__('Number of words in excerpt', 'envo-extra'),
    'section' => 'blog_posts',
    'default' => 10,
    'priority' => 10,
    'choices' => array(
        'min' => '0',
        'max' => '100',
        'step' => '1',
    ),
    'active_callback' => array(
        array(
            'setting' => 'woo_archive_product_excerpt',
            'operator' => '==',
            'value' => '1',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'settings' => 'blog_border',
    'type' => 'border',
    'label' => esc_html__('Article border', 'envo-extra'),
    'section' => 'blog_posts',
    'transport' => 'auto',
    'choices' => array(
        'units' => array('px', 'em')
    ),
    'default' => array(
        'style' => 'none',
        'top' => 0,
        'bottom' => 0,
        'left' => 0,
        'right' => 0,
        'color' => '',
        'unit' => 'px'
    ),
    'output' => array(
        array(
            'element' => '.archive-item'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'settings' => 'blog_box_shadow',
    'type' => 'box-shadow',
    'label' => esc_html__('Article box shadow', 'envo-extra'),
    'section' => 'blog_posts',
    'transport' => 'auto',
    'default' => array(
        'v_offset' => 0,
        'h_offset' => 0,
        'spread' => 0,
        'blur' => 0,
        'color' => ''
    ),
    'output' => array(
        array(
            'element' => '.archive-item'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'blog_spacing',
    'label' => esc_attr__('Article spacing', 'envo-extra'),
    'section' => 'blog_posts',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em', '%')
    ),
    'default' => array(
        'top' => '0',
        'right' => '0',
        'bottom' => '0',
        'left' => '0',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '.archive-item',
        ),
    ),
));