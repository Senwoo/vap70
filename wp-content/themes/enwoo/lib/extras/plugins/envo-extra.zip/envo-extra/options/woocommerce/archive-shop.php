<?php

if (!class_exists('Kirki')) {
    return;
}

Kirki::add_panel('woo_archive_section', array(
    'title' => esc_attr__('Archive/Shop', 'envo-extra'),
    'panel' => 'woo_section_main',
    'priority' => 10,
));



Kirki::add_section('woo_archive_global_section', array(
    'title' => esc_attr__('Global options', 'envo-extra'),
    'panel' => 'woo_archive_section',
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'slider',
    'settings' => 'archive_number_products',
    'label' => esc_attr__('Number of items', 'envo-extra'),
    'description' => esc_attr__('Change number of products displayed per page in archive(shop) page.', 'envo-extra'),
    'section' => 'woo_archive_global_section',
    'default' => 12,
    'priority' => 2,
    'choices' => array(
        'min' => 2,
        'max' => 64,
        'step' => 1,
    ),
));

Kirki::add_field('envo_extra', array(
    'type' => 'slider',
    'settings' => 'archive_number_columns',
    'label' => esc_attr__('Items per row', 'envo-extra'),
    'description' => esc_attr__('Change the number of products columns per row in archive(shop) page.', 'envo-extra'),
    'section' => 'woo_archive_global_section',
    'default' => 4,
    'priority' => 10,
    'choices' => array(
        'min' => 2,
        'max' => 5,
        'step' => 1,
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'toggle',
    'settings' => 'woo_archive_product_equal_height',
    'label' => esc_attr__('Products with equal height', 'envo-extra'),
    'section' => 'woo_archive_global_section',
    'default' => 1,
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'toggle',
    'settings' => 'woo_archive_breadcrumbs',
    'label' => esc_attr__('Breadcrumbs', 'envo-extra'),
    'section' => 'woo_archive_global_section',
    'default' => 1,
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'woo_archive_breadcrumb_font',
    'label' => esc_attr__('Breadcrubs font', 'envo-extra'),
    'section' => 'woo_archive_global_section',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '13px',
        'variant' => '400',
        'line-height' => '1.4',
        'letter-spacing' => '0px',
        'color' => '',
        'text-transform' => 'none',
        'text-decoration' => 'none',
        'word-spacing' => '0px',
        'text-align' => 'left',
        'margin-top' => '5px',
        'margin-bottom' => '5px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.archive .woo-breadcrumbs',
        ),
    ),
    'active_callback' => array(
        array(
            'setting' => 'woo_archive_breadcrumbs',
            'operator' => '==',
            'value' => '1',
        ),
    ),
));


Kirki::add_section('woo_archive_product_section', array(
    'title' => esc_attr__('Product', 'envo-extra'),
    'panel' => 'woo_archive_section',
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'settings' => 'woo_archive_product_border',
    'type' => 'border',
    'label' => esc_html__('Border', 'envo-extra'),
    'section' => 'woo_archive_product_section',
    'transport' => 'auto',
    'choices' => array(
        'units' => array('px', 'em')
    ),
    'default' => array(
        'style' => 'none',
        'top' => 0,
        'bottom' => 0,
        'left' => 0,
        'right' => 0,
        'unit' => 'px'
    ),
    'output' => array(
        array(
            'element' => '.woocommerce ul.products li.product'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'slider',
    'settings' => 'woo_archive_product_border_radius',
    'label' => esc_attr__('Border radius', 'envo-extra'),
    'section' => 'woo_archive_product_section',
    'default' => 0,
    'transport' => 'auto',
    'priority' => 10,
    'choices' => array(
        'min' => '0',
        'max' => '20',
        'step' => '1',
    ),
    'output' => array(
        array(
            'element' => '.woocommerce ul.products li.product',
            'property' => 'border-radius',
            'units' => 'px',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'slider',
    'settings' => 'woo_archive_product_shadow',
    'label' => esc_attr__('Shadow', 'envo-extra'),
    'section' => 'woo_archive_product_section',
    'default' => 0,
    'transport' => 'auto',
    'priority' => 10,
    'choices' => array(
        'min' => '0',
        'max' => '30',
        'step' => '1',
    ),
    'output' => array(
        array(
            'element' => '.woocommerce ul.products li.product, .woocommerce-page ul.products li.product',
            'property' => 'box-shadow',
            'value_pattern' => '0px 0px $px 0px rgba(0,0,0,0.25)'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'slider',
    'settings' => 'woo_archive_product_shadow_hover',
    'label' => esc_attr__('Shadow on hover', 'envo-extra'),
    'section' => 'woo_archive_product_section',
    'default' => 10,
    'transport' => 'auto',
    'priority' => 10,
    'choices' => array(
        'min' => '0',
        'max' => '30',
        'step' => '1',
    ),
    'output' => array(
        array(
            'element' => '.woocommerce ul.products li.product:hover, .woocommerce-page ul.products li.product:hover',
            'property' => 'box-shadow',
            'value_pattern' => '0px 0px $px 0px rgba(0,0,0,0.25)'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'woo_archive_product_padding',
    'label' => esc_attr__('Padding', 'envo-extra'),
    'section' => 'woo_archive_product_section',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em', '%')
    ),
    'default' => array(
        'top' => '0',
        'bottom' => '15',
        'left' => '0',
        'right' => '0',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '.woocommerce ul.products li.product',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'woo_archive_product_margin',
    'label' => esc_attr__('Margin', 'envo-extra'),
    'section' => 'woo_archive_product_section',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('em', 'px', '%')
    ),
    'default' => array(
        'top' => '0',
        'bottom' => '2.992',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'margin',
            'element' => '.woocommerce ul.products li.product',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'color',
    'settings' => 'woo_archive_product_bg',
    'label' => esc_attr__('Background', 'envo-extra'),
    'section' => 'woo_archive_product_section',
    'default' => '',
    'choices' => array(
        'alpha' => true,
    ),
    'transport' => 'auto',
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.woocommerce ul.products li.product, .woocommerce-page ul.products li.product, li.product-category.product, .woocommerce ul.products li.product .woocommerce-loop-category__title',
            'property' => 'background',
        ),
    ),
));


Kirki::add_section('woo_archive_image_section', array(
    'title' => esc_attr__('Image', 'envo-extra'),
    'panel' => 'woo_archive_section',
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'settings' => 'woo_archive_image_border',
    'type' => 'border',
    'label' => esc_html__('Border', 'envo-extra'),
    'section' => 'woo_archive_image_section',
    'transport' => 'auto',
    'choices' => array(
        'units' => array('px', 'em')
    ),
    'default' => array(
        'style' => 'none',
        'top' => 0,
        'bottom' => 0,
        'left' => 0,
        'right' => 0,
        'unit' => 'px'
    ),
    'output' => array(
        array(
            'element' => '.woocommerce ul.products li.product a .archive-img-wrap img:not(.secondary-image)'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'slider',
    'settings' => 'woo_archive_image_border_radius',
    'label' => esc_attr__('Border radius', 'envo-extra'),
    'section' => 'woo_archive_image_section',
    'default' => 0,
    'transport' => 'auto',
    'priority' => 10,
    'choices' => array(
        'min' => '0',
        'max' => '20',
        'step' => '1',
    ),
    'output' => array(
        array(
            'element' => '.woocommerce ul.products li.product a .archive-img-wrap img',
            'property' => 'border-radius',
            'units' => 'px',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'woo_archive_image_padding',
    'label' => esc_attr__('Padding', 'envo-extra'),
    'section' => 'woo_archive_image_section',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em', '%')
    ),
    'default' => array(
        'top' => '0',
        'bottom' => '0',
        'left' => '0',
        'right' => '0',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '.woocommerce ul.products li.product a .archive-img-wrap img',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'woo_archive_image_margin',
    'label' => esc_attr__('Margin', 'envo-extra'),
    'section' => 'woo_archive_image_section',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em', '%')
    ),
    'default' => array(
        'top' => '0',
        'bottom' => '0',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'margin',
            'element' => '.woocommerce ul.products li.product a .archive-img-wrap img:not(.secondary-image)',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'color',
    'settings' => 'woo_archive_image_bg',
    'label' => esc_attr__('Background', 'envo-extra'),
    'section' => 'woo_archive_image_section',
    'default' => '',
    'choices' => array(
        'alpha' => true,
    ),
    'transport' => 'auto',
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.woocommerce ul.products li.product a .archive-img-wrap img:not(.secondary-image)',
            'property' => 'background-color',
        ),
    ),
));


Kirki::add_section('woo_archive_title_section', array(
    'title' => esc_attr__('Title', 'envo-extra'),
    'panel' => 'woo_archive_section',
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'woo_archive_product_title',
    'label' => esc_attr__('Font', 'envo-extra'),
    'section' => 'woo_archive_title_section',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '16px',
        'variant' => '700',
        'line-height' => '1.6',
        'letter-spacing' => '0px',
        'color' => '',
        'text-transform' => 'none',
        'text-decoration' => 'none',
        'word-spacing' => '0px',
        'text-align' => 'none',
        'margin-top' => '5px',
        'margin-bottom' => '5px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.woocommerce ul.products li.product h3, li.product-category.product h3, .woocommerce ul.products li.product h2.woocommerce-loop-product__title, .woocommerce ul.products li.product h2.woocommerce-loop-category__title',
        ),
    ),
));


Kirki::add_section('woo_archive_price_section', array(
    'title' => esc_attr__('Price', 'envo-extra'),
    'panel' => 'woo_archive_section',
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'woo_archive_product_price',
    'label' => esc_attr__('Price', 'envo-extra'),
    'section' => 'woo_archive_price_section',
    'transport' => 'auto',
    'priority' => 10,
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '16px',
        'variant' => '400',
        'line-height' => '1.6',
        'letter-spacing' => '0px',
        'color' => '',
        'text-transform' => 'none',
        'text-decoration' => 'none',
        'word-spacing' => '0px',
        'text-align' => 'none',
        'margin-top' => '5px',
        'margin-bottom' => '5px',
    ),
    'output' => array(
        array(
            'element' => '.woocommerce ul.products li.product .price',
            'property' => 'color',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'woo_archive_product_price_del',
    'label' => esc_attr__('Del price', 'envo-extra'),
    'section' => 'woo_archive_price_section',
    'transport' => 'auto',
    'priority' => 10,
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '14px',
        'variant' => '300',
        'line-height' => '1.6',
        'letter-spacing' => '0px',
        'color' => '',
        'text-transform' => 'none',
        'text-decoration' => 'line-through',
        'word-spacing' => '0px',
    ),
    'output' => array(
        array(
            'element' => '.woocommerce ul.products li.product .price del',
            'property' => 'color',
        ),
    ),
));

Kirki::add_section('woo_archive_categories_section', array(
    'title' => esc_attr__('Categories', 'envo-extra'),
    'panel' => 'woo_archive_section',
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'toggle',
    'settings' => 'woo_archive_product_categories',
    'label' => esc_attr__('Categories', 'envo-extra'),
    'section' => 'woo_archive_categories_section',
    'default' => 1,
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'woo_archive_categories_typo',
    'label' => esc_attr__('Font', 'envo-extra'),
    'section' => 'woo_archive_categories_section',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '12px',
        'variant' => '400',
        'line-height' => '1.6',
        'letter-spacing' => '0px',
        'color' => '',
        'text-transform' => 'none',
        'text-decoration' => 'none',
        'word-spacing' => '0px',
        'text-align' => 'none',
        'margin-top' => '5px',
        'margin-bottom' => '5px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.archive-product-categories a, .archive-product-categories a:hover',
        ),
    ),
    'active_callback' => array(
        array(
            'setting' => 'woo_archive_product_categories',
            'operator' => '==',
            'value' => '1',
        ),
    ),
));


Kirki::add_section('woo_archive_button_section', array(
    'title' => esc_attr__('Button', 'envo-extra'),
    'panel' => 'woo_archive_section',
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'woo_archive_product_buttons_font',
    'label' => esc_attr__('Font', 'envo-extra'),
    'section' => 'woo_archive_button_section',
    'transport' => 'auto',
    'priority' => 10,
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '14px',
        'variant' => '300',
        'line-height' => '1.6',
        'letter-spacing' => '0px',
        'text-transform' => 'none',
        'text-decoration' => 'none',
        'word-spacing' => '0px',
        'text-align' => 'none',
    ),
    'output' => array(
        array(
            'element' => '.woocommerce ul.products li.product .button',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'woo_archive_product_buttons_padding',
    'label' => esc_attr__('Padding', 'envo-extra'),
    'section' => 'woo_archive_button_section',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em', '%')
    ),
    'default' => array(
        'top' => '6',
        'bottom' => '6',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '.woocommerce ul.products li.product .button',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'woo_archive_product_buttons_margin',
    'label' => esc_attr__('Margin', 'envo-extra'),
    'section' => 'woo_archive_button_section',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em', '%')
    ),
    'default' => array(
        'top' => '5',
        'bottom' => '5',
        'left' => '15',
        'right' => '15',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'margin',
            'element' => '.woocommerce ul.products li.product .button',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'multicolor',
    'settings' => 'woo_archive_product_buttons',
    'label' => esc_attr__('Colors', 'envo-extra'),
    'section' => 'woo_archive_button_section',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'link' => esc_attr__('Color', 'envo-extra'),
        'border' => esc_attr__('Border', 'envo-extra'),
        'background' => esc_attr__('Background', 'envo-extra'),
    ),
    'default' => array(
        'link' => '',
        'border' => '',
        'background' => '',
    ),
    'output' => array(
        array(
            'choice' => 'link',
            'element' => '.woocommerce ul.products li.product .button',
            'property' => 'color',
        ),
        array(
            'choice' => 'background',
            'element' => '.woocommerce ul.products li.product .button',
            'property' => 'background-color',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'multicolor',
    'settings' => 'woo_archive_product_buttons_hover',
    'label' => esc_attr__('Colors on hover', 'envo-extra'),
    'section' => 'woo_archive_button_section',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'link' => esc_attr__('Color', 'envo-extra'),
        'border' => esc_attr__('Border', 'envo-extra'),
        'background' => esc_attr__('Background', 'envo-extra'),
    ),
    'default' => array(
        'link' => '',
        'border' => '',
        'background' => '',
    ),
    'output' => array(
        array(
            'choice' => 'link',
            'element' => '.woocommerce ul.products li.product .button:hover',
            'property' => 'color',
        ),
        array(
            'choice' => 'border',
            'element' => '.woocommerce ul.products li.product .button:hover',
            'property' => 'border-color',
        ),
        array(
            'choice' => 'background',
            'element' => '.woocommerce ul.products li.product .button:hover',
            'property' => 'background-color',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'settings' => 'woo_archive_button_border',
    'type' => 'border',
    'label' => esc_html__('Border', 'envo-extra'),
    'section' => 'woo_archive_button_section',
    'transport' => 'auto',
    'choices' => array(
        'units' => array('px', 'em')
    ),
    'default' => array(
        'style' => 'solid',
        'top' => 1,
        'bottom' => 1,
        'left' => 1,
        'right' => 1,
        'unit' => 'px'
    ),
    'output' => array(
        array(
            'element' => '.woocommerce ul.products li.product .button'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'slider',
    'settings' => 'woo_archive_product_button_border_radius',
    'label' => esc_attr__('Border radius', 'envo-extra'),
    'section' => 'woo_archive_button_section',
    'default' => 0,
    'transport' => 'auto',
    'priority' => 10,
    'choices' => array(
        'min' => '0',
        'max' => '90',
        'step' => '1',
    ),
    'output' => array(
        array(
            'element' => '.woocommerce ul.products li.product .button',
            'property' => 'border-radius',
            'units' => 'px',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'settings' => 'woo_archive_button_box_shadow',
    'type' => 'box-shadow',
    'label' => esc_html__('Box shadow', 'envo-extra'),
    'section' => 'woo_archive_button_section',
    'transport' => 'auto',
    'default' => array(
        'v_offset' => 0,
        'h_offset' => 0,
        'spread' => 0,
        'blur' => 0,
        'color' => ''
    ),
    'output' => array(
        array(
            'element' => '.woocommerce ul.products li.product .button'
        ),
    ),
));




Kirki::add_section('woo_archive_rating_section', array(
    'title' => esc_attr__('Rating stars', 'envo-extra'),
    'panel' => 'woo_archive_section',
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'color',
    'settings' => 'woo_archive_product_rating',
    'label' => esc_attr__('Color', 'envo-extra'),
    'section' => 'woo_archive_rating_section',
    'default' => '',
    'transport' => 'auto',
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.woocommerce .star-rating span',
            'property' => 'color',
        ),
    ),
));



Kirki::add_section('woo_archive_sale_section', array(
    'title' => esc_attr__('Sale badge', 'envo-extra'),
    'panel' => 'woo_archive_section',
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'settings' => 'woo_archive_sale_border',
    'type' => 'border',
    'label' => esc_html__('Border', 'envo-extra'),
    'section' => 'woo_archive_sale_section',
    'transport' => 'auto',
    'choices' => array(
        'units' => array('px', 'em')
    ),
    'default' => array(
        'style' => 'none',
        'top' => 0,
        'bottom' => 0,
        'left' => 0,
        'right' => 0,
        'unit' => 'px'
    ),
    'output' => array(
        array(
            'element' => '.woocommerce ul.products li.product .onsale'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'slider-advanced',
    'settings' => 'woo_archive_sale_border_radius',
    'label' => esc_attr__('Border radius', 'envo-extra'),
    'section' => 'woo_archive_sale_section',
    'default' => 0,
    'transport' => 'auto',
    'priority' => 10,
    'choices' => array(
        'use_media_queries' => true,
        'units' => array(
            'px' => array(
                'min' => 0,
                'max' => 50,
                'step' => 1
            ),
            '%' => array(
                'min' => 0,
                'max' => 50,
                'step' => 1
            )
        ),
    ),
    'output' => array(
        array(
            'element' => '.woocommerce ul.products li.product .onsale',
            'property' => 'border-radius',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'woo_archive_sale_padding',
    'label' => esc_attr__('Padding', 'envo-extra'),
    'section' => 'woo_archive_sale_section',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em', '%')
    ),
    'default' => array(
        'top' => '5',
        'bottom' => '5',
        'left' => '8',
        'right' => '8',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '.woocommerce ul.products li.product .onsale',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'multicolor',
    'settings' => 'woo_archive_product_sale_colors',
    'label' => esc_attr__('Colors', 'envo-extra'),
    'section' => 'woo_archive_sale_section',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'link' => esc_attr__('Color', 'envo-extra'),
        'background' => esc_attr__('Background', 'envo-extra'),
    ),
    'default' => array(
        'link' => '',
        'background' => '',
    ),
    'output' => array(
        array(
            'choice' => 'link',
            'element' => '.woocommerce ul.products li.product .onsale',
            'property' => 'color',
        ),
        array(
            'choice' => 'background',
            'element' => '.woocommerce ul.products li.product .onsale',
            'property' => 'background-color',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'slider-advanced',
    'settings' => 'woo_archive_product_sale_pos_top',
    'label' => esc_attr__('Position from top', 'envo-extra'),
    'section' => 'woo_archive_sale_section',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array(
            'px' => array(
                'min' => -300,
                'max' => 300,
                'step' => 1
            ),
            '%' => array(
                'min' => 0,
                'max' => 100,
                'step' => 1
            )
        ),
    ),
    'default' => 0,
    'output' => array(
        array(
            'element' => '.woocommerce ul.products li.product .onsale',
            'property' => 'top',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'slider-advanced',
    'settings' => 'woo_archive_product_sale_pos_right',
    'label' => esc_attr__('Position from right', 'envo-extra'),
    'section' => 'woo_archive_sale_section',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array(
            'px' => array(
                'min' => -300,
                'max' => 300,
                'step' => 1
            ),
            '%' => array(
                'min' => 0,
                'max' => 100,
                'step' => 1
            )
        ),
    ),
    'default' => 0,
    'output' => array(
        array(
            'element' => '.woocommerce ul.products li.product .onsale',
            'property' => 'right',
        ),
    ),
));
