<?php

if (!class_exists('Kirki')) {
    return;
}
Kirki::add_section('header_title_tagline', array(
    'title' => esc_attr__('Header', 'envo-extra'),
    'panel' => 'envo_theme_panel',
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'title_margin',
    'label' => esc_html__('Header spacing', 'envo-extra'),
    'section' => 'header_title_tagline',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em')
    ),
    'priority' => 5,
    'default' => array(
        'top' => '15',
        'bottom' => '15',
    ),
    'output' => array(
        array(
            'element' => '.site-header',
            'property' => 'padding',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'header_logo_spacing',
    'label' => esc_attr__('Logo spacing', 'envo-extra'),
    'section' => 'header_title_tagline',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em')
    ),
    'priority' => 6,
    'default' => array(
        'top' => '0',
        'right' => '0',
        'bottom' => '0',
        'left' => '0',
    ),
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '.site-branding-logo img',
        ),
    ),
));

Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'header_title_spacing',
    'label' => esc_attr__('Site Title and Tagline spacing', 'envo-extra'),
    'section' => 'header_title_tagline',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em')
    ),
    'priority' => 7,
    'default' => array(
        'top' => '0',
        'right' => '0',
        'bottom' => '0',
        'left' => '0',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '.site-branding-text',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'header_typography_site_title',
    'label' => esc_attr__('Site title font', 'envo-extra'),
    'section' => 'header_title_tagline',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'color' => '',
        'variant' => '700',
        'letter-spacing' => '0px',
        'font-size' => '',
        'line-height' => '',
        'text-transform' => 'none',
        'margin-top' => '5px',
        'margin-bottom' => '5px',
        'word-spacing' => '0px',
        'text-decoration' => 'none'
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.site-branding-text h1.site-title a:hover, .site-branding-text .site-title a:hover, .site-branding-text h1.site-title, .site-branding-text .site-title, .site-branding-text h1.site-title a, .site-branding-text .site-title a',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'header_typography_site_desc',
    'transport' => 'auto',
    'label' => esc_attr__('Site description font', 'envo-extra'),
    'section' => 'header_title_tagline',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'color' => '',
        'variant' => '400',
        'letter-spacing' => '0px',
        'font-size' => '',
        'line-height' => '',
        'text-transform' => 'none',
        'margin-top' => '5px',
        'margin-bottom' => '5px',
        'word-spacing' => '0px',
        'text-decoration' => 'none'
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => 'p.site-description',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'header_typography_widgets',
    'transport' => 'auto',
    'label' => esc_attr__('Header widget area font', 'envo-extra'),
    'section' => 'header_title_tagline',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'color' => '',
        'variant' => '400',
        'letter-spacing' => '0px',
        'font-size' => '',
        'line-height' => '',
        'text-transform' => 'none',
        'margin-top' => '5px',
        'margin-bottom' => '5px',
        'word-spacing' => '0px',
        'text-decoration' => 'none'
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.site-heading-sidebar',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'color',
    'settings' => 'header_bg_color',
    'label' => esc_attr__('Header background', 'envo-extra'),
    'section' => 'header_title_tagline',
    'default' => '',
    'transport' => 'auto',
    'priority' => 30,
    'output' => array(
        array(
            'element' => '.site-header',
            'property' => 'background-color',
        ),
    ),
));

Kirki::add_field('envo_extra', array(
    'settings' => 'mainmenu_border',
    'type' => 'border',
    'label' => esc_html__('Menu bar border', 'envo-extra'),
    'section' => 'header_title_tagline',
    'transport' => 'auto',
    'choices' => array(
        'units' => array('px', 'em')
    ),
    'default' => array(
        'style' => 'solid',
        'top' => 1,
        'bottom' => 1,
        'color' => '#f6f6f6',
        'unit' => 'px'
    ),
    'output' => array(
        array(
            'element' => '#second-site-navigation'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'settings' => 'mainmenu_box_shadow',
    'type' => 'box-shadow',
    'label' => esc_html__('Menu bar box shadow', 'envo-extra'),
    'section' => 'header_title_tagline',
    'transport' => 'auto',
    'default' => array(
        'v_offset' => 0,
        'h_offset' => 0,
        'spread' => 0,
        'blur' => 0,
        'color' => ''
    ),
    'output' => array(
        array(
            'element' => '#second-site-navigation'
        ),
    ),
));

Kirki::add_field('envo_extra', array(
    'type' => 'color',
    'settings' => 'categories_search_bar_bg',
    'label' => esc_attr__('Secondary bar background color', 'envo-extra'),
    'section' => 'header_title_tagline',
    'default' => '',
    'transport' => 'auto',
    'priority' => 10,
    'output' => array(
        array(
            'element' => '#second-site-navigation',
            'property' => 'background-color',
        ),
    ),
));
