<?php

if (!class_exists('Kirki')) {
    return;
}

Kirki::add_panel('woo_product_section', array(
    'title' => esc_attr__('Product Page', 'envo-extra'),
    'panel' => 'woo_section_main',
    'priority' => 20,
));


Kirki::add_section('woo_product_global_section', array(
    'title' => esc_attr__('Global options', 'envo-extra'),
    'panel' => 'woo_product_section',
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'toggle',
    'settings' => 'woo_gallery_zoom',
    'label' => esc_attr__('Gallery zoom', 'envo-extra'),
    'section' => 'woo_product_global_section',
    'default' => 1,
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'toggle',
    'settings' => 'woo_gallery_lightbox',
    'label' => esc_attr__('Gallery lightbox', 'envo-extra'),
    'section' => 'woo_product_global_section',
    'default' => 1,
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'toggle',
    'settings' => 'woo_gallery_slider',
    'label' => esc_attr__('Gallery slider', 'envo-extra'),
    'section' => 'woo_product_global_section',
    'default' => 1,
    'priority' => 10,
));

Kirki::add_field('envo_extra', array(
    'type' => 'toggle',
    'settings' => 'woo_remove_related',
    'label' => esc_attr__('Related products', 'envo-extra'),
    'section' => 'woo_product_global_section',
    'default' => 1,
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'toggle',
    'settings' => 'woo_product_breadcrumbs',
    'label' => esc_attr__('Breadcrumbs', 'envo-extra'),
    'section' => 'woo_product_global_section',
    'default' => 1,
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'woo_product_breadcrumb_font',
    'label' => esc_attr__('Breadcrubs font', 'envo-extra'),
    'section' => 'woo_product_global_section',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '13px',
        'variant' => '400',
        'line-height' => '1.4',
        'letter-spacing' => '0px',
        'color' => '',
        'text-transform' => 'none',
        'text-decoration' => 'none',
        'word-spacing' => '0px',
        'text-align' => 'left',
        'margin-top' => '5px',
        'margin-bottom' => '5px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.single-product .woo-breadcrumbs',
        ),
    ),
    'active_callback' => array(
        array(
            'setting' => 'woo_product_breadcrumbs',
            'operator' => '==',
            'value' => '1',
        ),
    ),
));



Kirki::add_section('woo_product_title', array(
    'title' => esc_attr__('Title', 'envo-extra'),
    'panel' => 'woo_product_section',
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'woo_single_product_title',
    'label' => esc_attr__('Font', 'envo-extra'),
    'section' => 'woo_product_title',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '36px',
        'variant' => '700',
        'line-height' => '1.6',
        'letter-spacing' => '0px',
        'color' => '',
        'text-transform' => 'none',
        'text-decoration' => 'none',
        'word-spacing' => '0px',
        'text-align' => 'none',
        'margin-top' => '0px',
        'margin-bottom' => '10px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.woocommerce div.product .product_title',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'settings' => 'woo_product_title_border',
    'type' => 'border',
    'label' => esc_html__('Border', 'envo-extra'),
    'section' => 'woo_product_title',
    'transport' => 'auto',
    'choices' => array(
        'units' => array('px', 'em')
    ),
    'default' => array(
        'style' => 'none',
        'top' => 0,
        'bottom' => 0,
        'left' => 0,
        'right' => 0,
        'unit' => 'px'
    ),
    'output' => array(
        array(
            'element' => '.woocommerce div.product .product_title'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'woo_product_title_padding',
    'label' => esc_attr__('Padding', 'envo-extra'),
    'section' => 'woo_product_title',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em', '%')
    ),
    'default' => array(
        'top' => '0',
        'bottom' => '0',
        'left' => '0',
        'right' => '0',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '.woocommerce div.product .product_title',
        ),
    ),
));



Kirki::add_section('woo_product_price', array(
    'title' => esc_attr__('Price', 'envo-extra'),
    'panel' => 'woo_product_section',
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'woo_single_product_price',
    'label' => esc_attr__('Price', 'envo-extra'),
    'section' => 'woo_product_price',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '18px',
        'variant' => '300',
        'line-height' => '1.6',
        'letter-spacing' => '0px',
        'color' => '',
        'text-transform' => 'none',
        'text-decoration' => 'none',
        'word-spacing' => '0px',
        'text-align' => 'none',
        'margin-top' => '0px',
        'margin-bottom' => '10px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.woocommerce div.product p.price, .woocommerce div.product span.price',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'woo_single_product_price_del',
    'label' => esc_attr__('Del price', 'envo-extra'),
    'section' => 'woo_product_price',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '16px',
        'variant' => '300',
        'line-height' => '1.6',
        'letter-spacing' => '0px',
        'color' => '',
        'text-transform' => 'none',
        'text-decoration' => 'line-through',
        'word-spacing' => '0px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.woocommerce div.product p.price del, .woocommerce div.product span.price del',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'settings' => 'woo_product_price_border',
    'type' => 'border',
    'label' => esc_html__('Border', 'envo-extra'),
    'section' => 'woo_product_price',
    'transport' => 'auto',
    'choices' => array(
        'units' => array('px', 'em')
    ),
    'default' => array(
        'style' => 'none',
        'top' => 0,
        'bottom' => 0,
        'left' => 0,
        'right' => 0,
        'unit' => 'px'
    ),
    'output' => array(
        array(
            'element' => '.woocommerce div.product p.price, .woocommerce div.product span.price'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'woo_product_price_padding',
    'label' => esc_attr__('Padding', 'envo-extra'),
    'section' => 'woo_product_price',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em', '%')
    ),
    'default' => array(
        'top' => '0',
        'bottom' => '0',
        'left' => '0',
        'right' => '0',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '.woocommerce div.product p.price, .woocommerce div.product span.price',
        ),
    ),
));




Kirki::add_section('woo_product_sum', array(
    'title' => esc_attr__('Summary', 'envo-extra'),
    'panel' => 'woo_product_section',
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'woo_single_product_sum',
    'label' => esc_attr__('Font', 'envo-extra'),
    'section' => 'woo_product_sum',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '15px',
        'variant' => '300',
        'line-height' => '1.6',
        'letter-spacing' => '0px',
        'color' => '',
        'text-transform' => 'none',
        'text-decoration' => 'none',
        'word-spacing' => '0px',
        'text-align' => 'none',
        'margin-top' => '0px',
        'margin-bottom' => '0px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.woocommerce-product-details__short-description',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'settings' => 'woo_product_sum_border',
    'type' => 'border',
    'label' => esc_html__('Border', 'envo-extra'),
    'section' => 'woo_product_sum',
    'transport' => 'auto',
    'choices' => array(
        'units' => array('px', 'em')
    ),
    'default' => array(
        'style' => 'none',
        'top' => 0,
        'bottom' => 0,
        'left' => 0,
        'right' => 0,
        'unit' => 'px'
    ),
    'output' => array(
        array(
            'element' => '.woocommerce-product-details__short-description'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'woo_product_sum_padding',
    'label' => esc_attr__('Padding', 'envo-extra'),
    'section' => 'woo_product_sum',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em', '%')
    ),
    'default' => array(
        'top' => '0',
        'bottom' => '0',
        'left' => '0',
        'right' => '0',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '.woocommerce-product-details__short-description',
        ),
    ),
));



Kirki::add_section('woo_product_button', array(
    'title' => esc_attr__('Button and Quantity', 'envo-extra'),
    'panel' => 'woo_product_section',
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'woo_single_product_button_font',
    'label' => esc_attr__('Button font', 'envo-extra'),
    'section' => 'woo_product_button',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '15px',
        'variant' => '300',
        'line-height' => '1.6',
        'letter-spacing' => '0px',
        'color' => '',
        'text-transform' => 'none',
        'text-decoration' => 'none',
        'word-spacing' => '0px',
        'text-align' => 'none',
        'margin-top' => '0px',
        'margin-bottom' => '0px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.woocommerce .summary #respond input#submit, .woocommerce .summary a.button, .woocommerce .summary button.button, .woocommerce .summary input.button, .woocommerce .summary #respond input#submit.alt, .woocommerce .summary a.button.alt, .woocommerce .summary button.button.alt, .woocommerce .summary input.button.alt',
            
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'settings' => 'woo_product_button_border',
    'type' => 'border',
    'label' => esc_html__('Button border', 'envo-extra'),
    'section' => 'woo_product_button',
    'transport' => 'auto',
    'choices' => array(
        'units' => array('px', 'em')
    ),
    'default' => array(
        'style' => 'solid',
        'top' => 1,
        'bottom' => 1,
        'left' => 1,
        'right' => 1,
        'unit' => 'px'
    ),
    'output' => array(
        array(
            'element' => '.woocommerce .summary #respond input#submit, .woocommerce .summary a.button, .woocommerce .summary button.button, .woocommerce .summary input.button, .woocommerce .summary #respond input#submit.alt, .woocommerce .summary a.button.alt, .woocommerce .summary button.button.alt, .woocommerce .summary input.button.alt',
            
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'slider-advanced',
    'settings' => 'woo_product_button_radius',
    'label' => esc_attr__('Button border radius', 'envo-extra'),
    'section' => 'woo_product_button',
    'default' => 0,
    'transport' => 'auto',
    'priority' => 10,
    'choices' => array(
        'use_media_queries' => true,
        'units' => array(
            'px' => array(
                'min' => 0,
                'max' => 50,
                'step' => 1
            ),
            '%' => array(
                'min' => 0,
                'max' => 50,
                'step' => 1
            )
        ),
    ),
    'output' => array(
        array(
            'element' => '.woocommerce .summary #respond input#submit, .woocommerce .summary a.button, .woocommerce .summary button.button, .woocommerce .summary input.button, .woocommerce .summary #respond input#submit.alt, .woocommerce .summary a.button.alt, .woocommerce .summary button.button.alt, .woocommerce .summary input.button.alt',
            'property' => 'border-radius',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'woo_product_button_padding',
    'label' => esc_attr__('Button padding', 'envo-extra'),
    'section' => 'woo_product_button',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em', '%')
    ),
    'default' => array(
        'top' => '0',
        'bottom' => '0',
        'left' => '0',
        'right' => '0',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '.woocommerce .summary #respond input#submit, .woocommerce .summary a.button, .woocommerce .summary button.button, .woocommerce .summary input.button, .woocommerce .summary #respond input#submit.alt, .woocommerce .summary a.button.alt, .woocommerce .summary button.button.alt, .woocommerce .summary input.button.alt',
            
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'multicolor',
    'settings' => 'woo_single_product_buttons',
    'label' => esc_attr__('Button colors', 'envo-extra'),
    'section' => 'woo_product_button',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'link' => esc_attr__('Color', 'envo-extra'),
        'border' => esc_attr__('Border', 'envo-extra'),
        'background' => esc_attr__('Background', 'envo-extra'),
    ),
    'default' => array(
        'link' => '',
        'border' => '',
        'background' => 'transparent',
    ),
    'output' => array(
        array(
            'choice' => 'link',
            'element' => '.woocommerce .summary #respond input#submit, .woocommerce .summary a.button, .woocommerce .summary button.button, .woocommerce .summary input.button, .woocommerce .summary #respond input#submit.alt, .woocommerce .summary a.button.alt, .woocommerce .summary button.button.alt, .woocommerce .summary input.button.alt',
            'property' => 'color',
        ),
        array(
            'choice' => 'border',
            'element' => '.woocommerce .summary #respond input#submit, .woocommerce .summary a.button, .woocommerce .summary button.button, .woocommerce .summary input.button, .woocommerce .summary #respond input#submit.alt, .woocommerce .summary a.button.alt, .woocommerce .summary button.button.alt, .woocommerce .summary input.button.alt',
            'property' => 'border-color',
        ),
        array(
            'choice' => 'background',
            'element' => '.woocommerce .summary #respond input#submit, .woocommerce .summary a.button, .woocommerce .summary button.button, .woocommerce .summary input.button, .woocommerce .summary #respond input#submit.alt, .woocommerce .summary a.button.alt, .woocommerce .summary button.button.alt, .woocommerce .summary input.button.alt',
             'property' => 'background-color',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'multicolor',
    'settings' => 'woo_single_product_buttons_hover',
    'label' => esc_attr__('Button colors on hover', 'envo-extra'),
    'section' => 'woo_product_button',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'link' => esc_attr__('Color', 'envo-extra'),
        'border' => esc_attr__('Border', 'envo-extra'),
        'background' => esc_attr__('Background', 'envo-extra'),
    ),
    'default' => array(
        'link' => '',
        'border' => '',
        'background' => '',
    ),
    'output' => array(
        array(
            'choice' => 'link',
            'element' => '.woocommerce .summary #respond input#submit:hover, .woocommerce .summary a.button:hover, .woocommerce .summary button.button:hover, .woocommerce .summary input.button:hover, .woocommerce .summary #respond input#submit.alt:hover, .woocommerce .summary a.button.alt:hover, .woocommerce .summary button.button.alt:hover, .woocommerce .summary input.button.alt:hover',
            'property' => 'color',
        ),
        array(
            'choice' => 'border',
            'element' => '.woocommerce .summary #respond input#submit:hover, .woocommerce .summary a.button:hover, .woocommerce .summary button.button:hover, .woocommerce .summary input.button:hover, .woocommerce .summary #respond input#submit.alt:hover, .woocommerce .summary a.button.alt:hover, .woocommerce .summary button.button.alt:hover, .woocommerce .summary input.button.alt:hover',
            'property' => 'border-color',
        ),
        array(
            'choice' => 'background',
            'element' => '.woocommerce .summary #respond input#submit:hover, .woocommerce .summary a.button:hover, .woocommerce .summary button.button:hover, .woocommerce .summary input.button:hover, .woocommerce .summary #respond input#submit.alt:hover, .woocommerce .summary a.button.alt:hover, .woocommerce .summary button.button.alt:hover, .woocommerce .summary input.button.alt:hover',
            'property' => 'background-color',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'slider-advanced',
    'settings' => 'woo_product_quantity_height',
    'label' => esc_attr__('Quantity height', 'envo-extra'),
    'section' => 'woo_product_button',
    'default' => 36,
    'transport' => 'auto',
    'priority' => 10,
    'choices' => array(
        'use_media_queries' => true,
        'units' => array(
            'px' => array(
                'min' => 30,
                'max' => 80,
                'step' => 1
            )
        ),
    ),
    'output' => array(
        array(
            'element' => '.woocommerce .quantity .qty, .single-product div.product form.cart .plus, .single-product div.product form.cart .minus',
            'property' => 'height',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'radio-buttonset',
    'settings' => 'woo_hide_plus_minus',
    'label' => esc_attr__('Quantity plus/minus', 'envo-extra'),
    'section' => 'woo_product_button',
    'default' => 'block',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'block' => esc_attr__('Visible', 'envo-extra'),
        'none' => esc_attr__('Hidden', 'envo-extra'),
    ),
    'output' => array(
        array(
            'element' => '.single-product div.product form.cart .plus, .single-product div.product form.cart .minus',
            'property' => 'display',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'multicolor',
    'settings' => 'woo_single_product_plus_minus',
    'label' => esc_attr__('Plus/Minus buttons', 'envo-extra'),
    'section' => 'woo_product_button',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'link' => esc_attr__('Color', 'envo-extra'),
        'border' => esc_attr__('Border', 'envo-extra'),
        'background' => esc_attr__('Background', 'envo-extra'),
    ),
    'default' => array(
        'link' => '',
        'border' => '',
        'background' => 'transparent',
    ),
    'output' => array(
        array(
            'choice' => 'link',
            'element' => '.single-product div.product form.cart .plus, .single-product div.product form.cart .minus',
            'property' => 'color',
        ),
        array(
            'choice' => 'border',
            'element' => '.single-product div.product form.cart .plus, .single-product div.product form.cart .minus',
            'property' => 'border-color',
        ),
        array(
            'choice' => 'background',
            'element' => '.single-product div.product form.cart .plus, .single-product div.product form.cart .minus',
            'property' => 'background-color',
        ),
    ),
    'active_callback' => array(
        array(
            'setting' => 'woo_hide_plus_minus',
            'operator' => '==',
            'value' => 'block',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'multicolor',
    'settings' => 'woo_product_plus_minus_hover',
    'label' => esc_attr__('Plus/Minus buttons hover', 'envo-extra'),
    'section' => 'woo_product_button',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'link' => esc_attr__('Color', 'envo-extra'),
        'border' => esc_attr__('Border', 'envo-extra'),
        'background' => esc_attr__('Background', 'envo-extra'),
    ),
    'default' => array(
        'link' => '',
        'border' => '',
        'background' => '',
    ),
    'output' => array(
        array(
            'choice' => 'link',
            'element' => '.single-product div.product form.cart .plus:hover, .single-product div.product form.cart .minus:hover',
            'property' => 'color',
        ),
        array(
            'choice' => 'border',
            'element' => '.single-product div.product form.cart .plus:hover, .single-product div.product form.cart .minus:hover',
            'property' => 'border-color',
        ),
        array(
            'choice' => 'background',
            'element' => '.single-product div.product form.cart .plus:hover, .single-product div.product form.cart .minus:hover',
            'property' => 'background-color',
        ),
    ),
    'active_callback' => array(
        array(
            'setting' => 'woo_hide_plus_minus',
            'operator' => '==',
            'value' => 'block',
        ),
    ),
));



Kirki::add_section('woo_product_image', array(
    'title' => esc_attr__('Image', 'envo-extra'),
    'panel' => 'woo_product_section',
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'slider',
    'settings' => 'woo_single_image_width',
    'label' => esc_attr__('Image area width (in %)', 'envo-extra'),
    'section' => 'woo_product_image',
    'default' => '48',
    'priority' => 10,
    'choices' => array(
        'min' => '0',
        'max' => '100',
        'step' => '1',
    ),
    'output' => array(
        array(
            'element' => '.woocommerce-page #content div.product div.images, .woocommerce-page div.product div.images',
            'property' => 'width',
            'units' => '%',
            'media_query' => '@media (min-width: 769px)',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'settings' => 'woo_product_image_border',
    'type' => 'border',
    'label' => esc_html__('Image Border', 'envo-extra'),
    'section' => 'woo_product_image',
    'transport' => 'auto',
    'choices' => array(
        'units' => array('px', 'em')
    ),
    'default' => array(
        'style' => 'none',
        'top' => 0,
        'bottom' => 0,
        'left' => 0,
        'right' => 0,
        'unit' => 'px'
    ),
    'output' => array(
        array(
            'element' => '.woocommerce div.product div.images .woocommerce-product-gallery__wrapper img'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'woo_product_image_padding',
    'label' => esc_attr__('Image Padding', 'envo-extra'),
    'section' => 'woo_product_image',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em', '%')
    ),
    'default' => array(
        'top' => '0',
        'bottom' => '0',
        'left' => '0',
        'right' => '0',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '.woocommerce div.product div.images .woocommerce-product-gallery__wrapper img',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'settings' => 'woo_product_gallery_image_border',
    'type' => 'border',
    'label' => esc_html__('Gallery images border', 'envo-extra'),
    'section' => 'woo_product_image',
    'transport' => 'auto',
    'choices' => array(
        'units' => array('px', 'em')
    ),
    'default' => array(
        'style' => 'none',
        'top' => 0,
        'bottom' => 0,
        'left' => 0,
        'right' => 0,
        'unit' => 'px'
    ),
    'output' => array(
        array(
            'element' => '.woocommerce div.product div.images .flex-control-thumbs img'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'woo_product_gallery_image_padding',
    'label' => esc_attr__('Gallery images padding', 'envo-extra'),
    'section' => 'woo_product_image',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em', '%')
    ),
    'default' => array(
        'top' => '0',
        'bottom' => '0',
        'left' => '0',
        'right' => '0',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '.woocommerce div.product div.images .flex-control-thumbs img',
        ),
    ),
));



Kirki::add_section('woo_product_tabs', array(
    'title' => esc_attr__('Tabs', 'envo-extra'),
    'panel' => 'woo_product_section',
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'woo_product_tabs_font',
    'label' => esc_attr__('Tabs font', 'envo-extra'),
    'section' => 'woo_product_tabs',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '15px',
        'variant' => '300',
        'line-height' => '1.6',
        'letter-spacing' => '0px',
        'color' => '',
        'text-transform' => 'none',
        'text-decoration' => 'none',
        'word-spacing' => '0px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.woocommerce div.product .woocommerce-tabs ul.tabs.wc-tabs li a',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'woo_product_tabs_content_font',
    'label' => esc_attr__('Tabs content font', 'envo-extra'),
    'section' => 'woo_product_tabs',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '18px',
        'variant' => '300',
        'line-height' => '1.6',
        'letter-spacing' => '0px',
        'color' => '',
        'text-transform' => 'none',
        'text-decoration' => 'none',
        'word-spacing' => '0px',
        'text-align' => 'none',
        'margin-top' => '0px',
        'margin-bottom' => '0px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.woocommerce div.product .woocommerce-tabs .panel',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'radio-buttonset',
    'settings' => 'woo_single_tab_position',
    'label' => __('Tab titles align', 'envo-extra'),
    'section' => 'woo_product_tabs',
    'default' => 'left',
    'transport' => 'auto',
    'priority' => 10,
    'choices' => array(
        'left' => '<i class="dashicons dashicons-editor-alignleft"></i>',
        'center' => '<i class="dashicons dashicons-editor-aligncenter"></i>',
        'right' => '<i class="dashicons dashicons-editor-alignright"></i>',
    ),
    'output' => array(
        array(
            'element' => '.woocommerce div.product .woocommerce-tabs ul.tabs',
            'property' => 'text-align',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'multicolor',
    'settings' => 'woo_single_product_active_tabs',
    'label' => esc_attr__('Active tab', 'envo-extra'),
    'section' => 'woo_product_tabs',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'link' => esc_attr__('Color', 'envo-extra'),
        'background' => esc_attr__('Background', 'envo-extra'),
        'line' => esc_attr__('Line', 'envo-extra'),
    ),
    'default' => array(
        'link' => '',
        'background' => '',
        'line' => '',
    ),
    'output' => array(
        array(
            'choice' => 'link',
            'element' => '.woocommerce div.product .woocommerce-tabs ul.tabs.wc-tabs li.active a',
            'property' => 'color',
        ),
        array(
            'choice' => 'background',
            'element' => '.woocommerce div.product .woocommerce-tabs ul.tabs.wc-tabs li.active a',
            'property' => 'background-color',
        ),
        array(
            'choice' => 'line',
            'element' => '.woocommerce div.product .woocommerce-tabs ul.tabs li.active',
            'property' => 'border-bottom-color',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'multicolor',
    'settings' => 'woo_single_product_inactive_tabs',
    'label' => esc_attr__('Inactive tab', 'envo-extra'),
    'section' => 'woo_product_tabs',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'link' => esc_attr__('Color', 'envo-extra'),
        'background' => esc_attr__('Background', 'envo-extra'),
    ),
    'default' => array(
        'link' => '',
        'background' => '',
    ),
    'output' => array(
        array(
            'choice' => 'link',
            'element' => '.woocommerce div.product .woocommerce-tabs ul.tabs.wc-tabs li a',
            'property' => 'color',
        ),
        array(
            'choice' => 'background',
            'element' => '.woocommerce div.product .woocommerce-tabs ul.tabs.wc-tabs li a',
            'property' => 'background-color',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'settings' => 'woo_product_tabs_border',
    'type' => 'border',
    'label' => esc_html__('Tabs border', 'envo-extra'),
    'section' => 'woo_product_tabs',
    'transport' => 'auto',
    'choices' => array(
        'units' => array('px', 'em')
    ),
    'default' => array(
        'style' => 'solid',
        'top' => 1,
        'bottom' => 1,
        'left' => 0,
        'right' => 0,
        'unit' => 'px',
        'color' => '#e8e8e8'
    ),
    'output' => array(
        array(
            'element' => '.woocommerce div.product .woocommerce-tabs ul.tabs'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'woo_product_tabs_content_padding',
    'label' => esc_attr__('Content padding', 'envo-extra'),
    'section' => 'woo_product_tabs',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em', '%')
    ),
    'default' => array(
        'top' => '0',
        'bottom' => '0',
        'left' => '0',
        'right' => '0',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '.woocommerce div.product .woocommerce-tabs .panel',
        ),
    ),
));



Kirki::add_section('woo_product_meta', array(
    'title' => esc_attr__('Meta', 'envo-extra'),
    'panel' => 'woo_product_section',
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'radio-buttonset',
    'settings' => 'woo_hide_sku',
    'label' => esc_attr__('SKU', 'envo-extra'),
    'section' => 'woo_product_meta',
    'default' => 'block',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'block' => esc_attr__('Visible', 'envo-extra'),
        'none' => esc_attr__('Hidden', 'envo-extra'),
    ),
    'output' => array(
        array(
            'element' => '.woocommerce div.product .product_meta>span.sku_wrapper',
            'property' => 'display',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'radio-buttonset',
    'settings' => 'woo_hide_cats',
    'label' => esc_attr__('Categories', 'envo-extra'),
    'section' => 'woo_product_meta',
    'default' => 'block',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'block' => esc_attr__('Visible', 'envo-extra'),
        'none' => esc_attr__('Hidden', 'envo-extra'),
    ),
    'output' => array(
        array(
            'element' => '.woocommerce div.product .product_meta>span.posted_in',
            'property' => 'display',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'radio-buttonset',
    'settings' => 'woo_hide_tags',
    'label' => esc_attr__('Tags', 'envo-extra'),
    'section' => 'woo_product_meta',
    'default' => 'block',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'block' => esc_attr__('Visible', 'envo-extra'),
        'none' => esc_attr__('Hidden', 'envo-extra'),
    ),
    'output' => array(
        array(
            'element' => '.woocommerce div.product .product_meta>span.tagged_as',
            'property' => 'display',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'woo_product_meta_font',
    'label' => esc_attr__('Font', 'envo-extra'),
    'section' => 'woo_product_meta',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '15px',
        'variant' => '300',
        'line-height' => '1.6',
        'letter-spacing' => '0px',
        'color' => '',
        'text-transform' => 'none',
        'text-decoration' => 'none',
        'word-spacing' => '0px',
        'text-align' => 'none',
        'margin-top' => '0px',
        'margin-bottom' => '0px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.product_meta',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'settings' => 'woo_product_meta_border',
    'type' => 'border',
    'label' => esc_html__('Border', 'envo-extra'),
    'section' => 'woo_product_meta',
    'transport' => 'auto',
    'choices' => array(
        'units' => array('px', 'em')
    ),
    'default' => array(
        'style' => 'none',
        'top' => 0,
        'bottom' => 0,
        'left' => 0,
        'right' => 0,
        'unit' => 'px'
    ),
    'output' => array(
        array(
            'element' => '.product_meta'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'woo_product_meta_padding',
    'label' => esc_attr__('Padding', 'envo-extra'),
    'section' => 'woo_product_meta',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em', '%')
    ),
    'default' => array(
        'top' => '0',
        'bottom' => '0',
        'left' => '0',
        'right' => '0',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '.product_meta',
        ),
    ),
));





Kirki::add_field('envo_extra', array(
    'type' => 'color',
    'settings' => 'woo_single_product_rating',
    'label' => esc_attr__('Rating stars', 'envo-extra'),
    'section' => 'main_typography_woo_product_section',
    'default' => '',
    'transport' => 'auto',
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.woocommerce .summary .star-rating span',
            'property' => 'color',
        ),
    ),
));


Kirki::add_section('woo_product_sale', array(
    'title' => esc_attr__('Sale', 'envo-extra'),
    'panel' => 'woo_product_section',
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'settings' => 'woo_product_sale_border',
    'type' => 'border',
    'label' => esc_html__('Border', 'envo-extra'),
    'section' => 'woo_product_sale',
    'transport' => 'auto',
    'choices' => array(
        'units' => array('px', 'em')
    ),
    'default' => array(
        'style' => 'none',
        'top' => 0,
        'bottom' => 0,
        'left' => 0,
        'right' => 0,
        'unit' => 'px'
    ),
    'output' => array(
        array(
            'element' => '.single.woocommerce span.onsale'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'slider-advanced',
    'settings' => 'woo_product_sale_border_radius',
    'label' => esc_attr__('Border radius', 'envo-extra'),
    'section' => 'woo_product_sale',
    'default' => 3,
    'transport' => 'auto',
    'priority' => 10,
    'choices' => array(
        'use_media_queries' => true,
        'units' => array(
            'px' => array(
                'min' => 0,
                'max' => 50,
                'step' => 1
            ),
            '%' => array(
                'min' => 0,
                'max' => 50,
                'step' => 1
            )
        ),
    ),
    'output' => array(
        array(
            'element' => '.single.woocommerce span.onsale',
            'property' => 'border-radius',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'woo_product_sale_padding',
    'label' => esc_attr__('Padding', 'envo-extra'),
    'section' => 'woo_product_sale',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em', '%')
    ),
    'default' => array(
        'top' => '5',
        'bottom' => '5',
        'left' => '8',
        'right' => '8',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '.single.woocommerce span.onsale',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'multicolor',
    'settings' => 'woo_product_sale_colors',
    'label' => esc_attr__('Colors', 'envo-extra'),
    'section' => 'woo_product_sale',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'link' => esc_attr__('Color', 'envo-extra'),
        'background' => esc_attr__('Background', 'envo-extra'),
    ),
    'default' => array(
        'link' => '',
        'background' => '',
    ),
    'output' => array(
        array(
            'choice' => 'link',
            'element' => '.single.woocommerce span.onsale',
            'property' => 'color',
        ),
        array(
            'choice' => 'background',
            'element' => '.single.woocommerce span.onsale',
            'property' => 'background-color',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'slider-advanced',
    'settings' => 'woo_product_sale_pos_top',
    'label' => esc_attr__('Position from top', 'envo-extra'),
    'section' => 'woo_product_sale',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array(
            'px' => array(
                'min' => -300,
                'max' => 300,
                'step' => 1
            ),
            '%' => array(
                'min' => 0,
                'max' => 100,
                'step' => 1
            )
        ),
    ),
    'default' => -5,
    'output' => array(
        array(
            'element' => '.single.woocommerce span.onsale',
            'property' => 'top',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'slider-advanced',
    'settings' => 'woo_product_sale_pos_right',
    'label' => esc_attr__('Position from left', 'envo-extra'),
    'section' => 'woo_product_sale',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array(
            'px' => array(
                'min' => -300,
                'max' => 300,
                'step' => 1
            ),
            '%' => array(
                'min' => 0,
                'max' => 100,
                'step' => 1
            )
        ),
    ),
    'default' => -5,
    'output' => array(
        array(
            'element' => '.single.woocommerce span.onsale',
            'property' => 'left',
        ),
    ),
));