var kikriMetaboxControl = {
	
	params: null,
	container: null,
	
	initKirkiMetabox: function(){
	},
	
	set: function( value ) {
		
	}
};

( function() {
	'use strict';

	jQuery( document ).ready( function ( e )
	{
		
	});
} );