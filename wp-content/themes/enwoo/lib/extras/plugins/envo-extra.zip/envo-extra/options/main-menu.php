<?php

if (!class_exists('Kirki')) {
    return;
}
Kirki::add_panel('theme_menus', array(
    'title' => esc_attr__('Menus', 'envo-extra'),
    'panel' => 'envo_theme_panel',
    'priority' => 15,
));

Kirki::add_section('main_menu', array(
    'title' => esc_attr__('Main Menu', 'envo-extra'),
    'panel' => 'theme_menus',
    'priority' => 10,
));

Kirki::add_section('secondary_menu', array(
    'title' => esc_attr__('Secondary Menu', 'envo-extra'),
    'panel' => 'theme_menus',
    'priority' => 20,
));

Kirki::add_section('category_menu', array(
    'title' => esc_attr__('Category Menu', 'envo-extra'),
    'panel' => 'theme_menus',
    'priority' => 30,
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'typography_mainmenu',
    'label' => esc_attr__('Menu Font', 'envo-extra'),
    'section' => 'main_menu',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '15px',
        'variant' => '400',
        'letter-spacing' => '0px',
        'text-transform' => 'uppercase',
        'color' => '',
        'word-spacing'     => '0px',
        'text-decoration' => 'none'
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '#site-navigation, #site-navigation .navbar-nav > li > a, #site-navigation .dropdown-menu > li > a',
        ),
        array(
            'choice' => 'color',
            'element' => '.open-panel span',
            'property' => 'background-color',
        ),
        array(
            'choice' => 'color',
            'element' => '.navbar-default .navbar-brand.brand-absolute',
            'property' => 'color',
        ),
    ),
));

Kirki::add_field('envo_extra', array(
    'type' => 'multicolor',
    'settings' => 'main_menu_colors',
    'label' => esc_attr__('Main Menu Colors', 'envo-extra'),
    'section' => 'main_menu',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'bg_color_mainmenu' => esc_attr__('Menu Background', 'envo-extra'),
        'text_hover_mainmenu' => esc_attr__('Font hover', 'envo-extra'),
        'bg_text_hover_mainmenu' => esc_attr__('Item background hover', 'envo-extra'),
        'active_text_mainmenu' => esc_attr__('Active item font', 'envo-extra'),
        'active_text_bg_mainmenu' => esc_attr__('Active item background', 'envo-extra'),
    ),
    'default' => array(
        'bg_color_mainmenu' => '',
        'text_hover_mainmenu' => '',
        'bg_text_hover_mainmenu' => '',
        'active_text_mainmenu' => '',
        'active_text_bg_mainmenu' => '',
    ),
    'output' => array(
        array(
            'choice' => 'bg_color_mainmenu',
            'element' => '#site-navigation, #site-navigation .dropdown-menu, #site-navigation.shrink, .header-cart-block .header-cart-inner ul.site-header-cart, .center-cart-middle',
            'property' => 'background-color',
        ),
        array(
            'choice' => 'bg_color_mainmenu',
            'element' => '#site-navigation .navbar-nav a, .openNav .menu-container',
            'property' => 'background-color',
            'media_query' => '@media (max-width: 767px)',
        ),
        array(
            'choice' => 'text_hover_mainmenu',
            'element' => '#site-navigation .navbar-nav > .open > a:hover, #site-navigation .navbar-nav > li > a:hover, #site-navigation .dropdown-menu > li > a:hover',
            'property' => 'color',
        ),
        array(
            'choice' => 'text_hover_mainmenu',
            'element' => '#site-navigation .navbar-nav a:hover',
            'property' => 'color',
            'media_query' => '@media (max-width: 767px)',
            'suffix' => '!important',
        ),
        array(
            'choice' => 'bg_text_hover_mainmenu',
            'element' => '#site-navigation .navbar-nav > li > a:hover, #site-navigation .dropdown-menu > li > a:hover, #site-navigation .nav .open > a, #site-navigation .nav .open > a:hover, #site-navigation .nav .open > a:focus',
            'property' => 'background-color',
        ),
        array(
            'choice' => 'bg_text_hover_mainmenu',
            'element' => '#site-navigation .navbar-nav a:hover',
            'property' => 'background-color',
            'media_query' => '@media (max-width: 767px)',
            'suffix' => '!important',
        ),
        array(
            'choice' => 'active_text_mainmenu',
            'element' => '#site-navigation .navbar-nav > li.active > a, #site-navigation .dropdown-menu > .active.current-menu-item > a, .dropdown-menu > .active > a, .home-icon.front_page_on i, .navbar-default .navbar-nav > .open > a',
            'property' => 'color',
        ),
        array(
            'choice' => 'active_text_mainmenu',
            'element' => '#site-navigation .navbar-nav .active a',
            'property' => 'color',
            'media_query' => '@media (max-width: 767px)',
            'suffix' => '!important',
        ),
        array(
            'choice' => 'active_text_bg_mainmenu',
            'element' => '#site-navigation .navbar-nav > li.active > a, #site-navigation .dropdown-menu > .active.current-menu-item > a, .dropdown-menu > .active > a, li.home-icon.front_page_on, li.home-icon.front_page_on:before',
            'property' => 'background-color',
        ),
        array(
            'choice' => 'active_text_bg_mainmenu',
            'element' => '#site-navigation .navbar-nav .active.current-menu-item a, .dropdown-menu > .active > a',
            'property' => 'background-color',
            'media_query' => '@media (max-width: 767px)',
            'suffix' => '!important',
        ),
    ),
));

Kirki::add_field('envo_extra', array(
	'settings' => 'submenu_border',
	'type' => 'border',
	'label' => esc_html__( 'Sub-menu border', 'envo-extra' ),
	'section' => 'main_menu',
        'transport' => 'auto',
	'choices' => array(
		'units' => array( 'px', 'em' )
	),
	'default' => array(
		'style' => 'solid',
		'top' => 1,
		'bottom' => 1,
		'color' => '#f6f6f6',
		'unit' => 'px'
	),
        'output' => array(
        array(
            'element' => '.navbar-nav li:hover .dropdown-menu'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
	'settings' => 'submenu_box_shadow',
	'type' => 'box-shadow',
	'label' => esc_html__( 'Sub-menu box shadow', 'envo-extra' ),
	'section' => 'main_menu',
	'transport' => 'auto',
	'default' => array(
		'v_offset' => 0,
		'h_offset' => 0,
		'spread' => 0,
		'blur' => 0,
		'color' => ''
	),
    'output' => array(
        array(
            'element' => '.navbar-nav li:hover .dropdown-menu'
        ),
    ),
));

Kirki::add_field('envo_extra', array(
    'type' => 'multicolor',
    'settings' => 'mainmenu_desc_color',
    'label' => esc_attr__('Menu badge (description) colors', 'envo-extra'),
    'section' => 'main_menu',
    'default' => '',
    'transport' => 'auto',
    'priority' => 10,
    'choices' => array(
        'font' => esc_attr__('Font', 'envo-extra'),
        'bg' => esc_attr__('Background', 'envo-extra'),
    ),
    'default' => array(
        'font' => '',
        'bg' => '',
    ),
    'output' => array(
        array(
            'choice' => 'font',
            'element' => '.menu-item .menu-description, .mobile-cart .amount-cart, .mobile-cart .cart-contents span.count',
            'property' => 'color',
        ),
        array(
            'choice' => 'bg',
            'element' => '.menu-item .menu-description, .mobile-cart .amount-cart, .mobile-cart .cart-contents span.count',
            'property' => 'background-color',
        ),
        array(
            'choice' => 'bg',
            'element' => '.menu-item .menu-description:after',
            'property' => 'border-top-color',
        ),
        array(
            'choice' => 'bg',
            'element' => '.mobile-cart .amount-cart:before',
            'property' => 'border-right-color',
        ),
    ),
));

Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'typography_category_menu',
    'label' => esc_attr__('Menu Font', 'envo-extra'),
    'section' => 'category_menu',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '15px',
        'variant' => '400',
        'letter-spacing' => '0px',
        'text-transform' => 'uppercase',
        'word-spacing'     => '0px',
        'text-decoration' => 'none',
        'color' => ''
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.envo-categories-menu, .envo-categories-menu > li > a, .envo-categories-menu .dropdown-menu > li > a',
        ),
    ),
));

Kirki::add_field('envo_extra', array(
    'type' => 'multicolor',
    'settings' => 'categories_colors',
    'label' => esc_attr__('Category menu', 'envo-extra'),
    'section' => 'category_menu',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'bg' => esc_attr__('Background', 'envo-extra'),
    ),
    'default' => array(
        'font' => '',
    ),
    'output' => array(
        array(
            'choice' => 'bg',
            'element' => '.navbar-nav.envo-categories-menu',
            'property' => 'background-color',
            'suffix' => '!important',
        ),
        
    ),
));

Kirki::add_field('envo_extra', array(
    'type' => 'multicolor',
    'settings' => 'category_menu_colors',
    'label' => esc_attr__('Sub-level menu colors', 'envo-extra'),
    'section' => 'category_menu',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'bg_color_mainmenu' => esc_attr__('Menu Background', 'envo-extra'),
        'text_hover_mainmenu' => esc_attr__('Font hover', 'envo-extra'),
        'bg_text_hover_mainmenu' => esc_attr__('Item background hover', 'envo-extra'),
        'active_text_mainmenu' => esc_attr__('Active item font', 'envo-extra'),
        'active_text_bg_mainmenu' => esc_attr__('Active item background', 'envo-extra'),
    ),
    'default' => array(
        'bg_color_mainmenu' => '',
        'text_hover_mainmenu' => '',
        'bg_text_hover_mainmenu' => '',
        'active_text_mainmenu' => '',
        'active_text_bg_mainmenu' => '',
    ),
    'output' => array(
        array(
            'choice' => 'bg_color_mainmenu',
            'element' => '.envo-categories-menu .dropdown-menu',
            'property' => 'background-color',
        ),
        array(
            'choice' => 'text_hover_mainmenu',
            'element' => '.envo-categories-menu > a:hover, .envo-categories-menu > li > a:hover, .envo-categories-menu.nav.navbar-nav .dropdown-menu > li > a:hover',
            'property' => 'color',
        ),

        array(
            'choice' => 'bg_text_hover_mainmenu',
            'element' => '.envo-categories-menu > li > a:hover, .envo-categories-menu .dropdown-menu > li > a:hover, .envo-categories-menu .dropdown-menu > a:hover',
            'property' => 'background-color',
        ),
        array(
            'choice' => 'active_text_mainmenu',
            'element' => '.envo-categories-menu > li.active > a, .envo-categories-menu .dropdown-menu > .active.current-menu-item > a, .envo-categories-menu .dropdown-menu > .active > a',
            'property' => 'color',
        ),
        array(
            'choice' => 'active_text_bg_mainmenu',
            'element' => '.envo-categories-menu > li.active > a, .envo-categories-menu .dropdown-menu > .active.current-menu-item > a, .envo-categories-menu .dropdown-menu > .active > a',
            'property' => 'background-color',
        ),
    ),
));

Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'typography_secondary_menu',
    'label' => esc_attr__('Menu Font', 'envo-extra'),
    'section' => 'secondary_menu',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '20px',
        'variant' => '400',
        'letter-spacing' => '0px',
        'text-transform' => 'uppercase',
        'word-spacing'     => '0px',
        'text-decoration' => 'none',
        'color' => ''
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '#theme-menu-second .navbar-nav > li > a',
        )
    ),
));

Kirki::add_field('envo_extra', array(
    'type' => 'multicolor',
    'settings' => 'secondary_menu_colors',
    'label' => esc_attr__('Secondary Menu', 'envo-extra'),
    'section' => 'secondary_menu',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'font-hover' => esc_attr__('Font hover', 'envo-extra'),
        'bg' => esc_attr__('Background', 'envo-extra'),
        'bg-hover' => esc_attr__('Background hover', 'envo-extra'),
        'font-active' => esc_attr__('Font active', 'envo-extra'),
        'bg-active' => esc_attr__('Background active', 'envo-extra'),
    ),
    'default' => array(
        'bg' => '',
        'font-hover' => '',
        'bg-hover' => '',
        'font-active' => '',
        'bg-active' => '',
    ),
    'output' => array(
        array(
            'choice' => 'bg',
            'element' => '#theme-menu-second .navbar-nav > li > a',
            'property' => 'background-color',
            'suffix' => '!important',
        ),
        array(
            'choice' => 'font-hover',
            'element' => '#theme-menu-second .navbar-nav > li > a:hover',
            'property' => 'color',
            'suffix' => '!important',
        ),
        array(
            'choice' => 'bg-hover',
            'element' => '#theme-menu-second .navbar-nav > li > a:hover',
            'property' => 'background-color',
            'suffix' => '!important',
        ),
        array(
            'choice' => 'font-active',
            'element' => '#theme-menu-second .navbar-nav > li.active > a',
            'property' => 'color',
            'suffix' => '!important',
        ),
        array(
            'choice' => 'bg-active',
            'element' => '#theme-menu-second .navbar-nav > li.active > a',
            'property' => 'background-color',
            'suffix' => '!important',
        ),
    ),
));