<?php

if (!class_exists('Kirki')) {
    return;
}

Kirki::add_section('main_sidebar', array(
    'title' => esc_attr__('Sidebar', 'envo-extra'),
    'panel' => 'envo_theme_panel',
    'priority' => 40,
));
Kirki::add_field('envo_extra', array(
    'type' => 'radio-buttonset',
    'settings' => 'main_sidebar_position',
    'label' => esc_attr__('Sidebar position', 'envo-extra'),
    'section' => 'main_sidebar',
    'default' => 'left',
    'priority' => 5,
    'transport' => 'auto',
    'choices' => array(
        'right' => esc_attr__('Left', 'envo-extra'),
        'left' => esc_attr__('Right', 'envo-extra'),
    ),
    'output' => array(
        array(
            'element' => '.blog .page-area .col-md-9, .archive .page-area .col-md-9, article.col-md-9',
            'property' => 'float',
        ),
    ),
));

Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'awidget_title_color',
    'label' => esc_attr__('Widget titles', 'envo-extra'),
    'section' => 'main_sidebar',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '15px',
        'variant' => '700',
        'line-height' => '1.6',
        'letter-spacing' => '0px',
        'color' => '',
        'text-transform' => 'uppercase',
        'word-spacing' => '0px',
        'text-align' => 'none',
        'margin-top' => '5px',
        'margin-bottom' => '5px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '#sidebar .widget-title',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'sidebar_widget_font',
    'label' => esc_attr__('Font', 'envo-extra'),
    'section' => 'main_sidebar',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '15px',
        'variant' => '400',
        'line-height' => '1.6',
        'letter-spacing' => '0px',
        'color' => '',
        'text-transform' => 'uppercase',
        'word-spacing' => '0px',
        'text-align' => 'none',
        'margin-top' => '5px',
        'margin-bottom' => '5px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '#sidebar .widget',
        ),
    ),
));

Kirki::add_field('envo_extra', array(
    'type' => 'multicolor',
    'settings' => 'sidebar_links',
    'label' => esc_attr__('Widget links', 'envo-extra'),
    'section' => 'main_sidebar',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'link' => esc_attr__('Links', 'envo-extra'),
        'link-hover' => esc_attr__('Links hover', 'envo-extra'),
    ),
    'default' => array(
        'link' => '',
        'link-hover' => '',
    ),
    'output' => array(
        array(
            'choice' => 'link',
            'element' => '#sidebar .widget a',
            'property' => 'color',
        ),
        array(
            'choice' => 'link-hover',
            'element' => '#sidebar .widget a:hover',
            'property' => 'color',
        ),
        
    ),
));

Kirki::add_field('envo_extra', array(
    'settings' => 'sidebar_border',
    'type' => 'border',
    'label' => esc_html__('Sidebar border', 'envo-extra'),
    'section' => 'main_sidebar',
    'transport' => 'auto',
    'choices' => array(
        'units' => array('px', 'em')
    ),
    'default' => array(
        'style' => 'none',
        'top' => 0,
        'bottom' => 0,
        'left' => 0,
        'right' => 0,
        'color' => '',
        'unit' => 'px'
    ),
    'output' => array(
        array(
            'element' => '#sidebar'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'settings' => 'sidebar_box_shadow',
    'type' => 'box-shadow',
    'label' => esc_html__('Sidebar box shadow', 'envo-extra'),
    'section' => 'main_sidebar',
    'transport' => 'auto',
    'default' => array(
        'v_offset' => 0,
        'h_offset' => 0,
        'spread' => 0,
        'blur' => 0,
        'color' => ''
    ),
    'output' => array(
        array(
            'element' => '#sidebar'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'sidebar_spacing',
    'label' => esc_attr__('Sidebar spacing', 'envo-extra'),
    'section' => 'main_sidebar',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em', '%')
    ),
    'default' => array(
        'top' => '0',
        'right' => '0',
        'bottom' => '0',
        'left' => '0',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '#sidebar',
        ),
    ),
));

Kirki::add_field('envo_extra', array(
    'settings' => 'widgets_border',
    'type' => 'border',
    'label' => esc_html__('Widgets border', 'envo-extra'),
    'section' => 'main_sidebar',
    'transport' => 'auto',
    'choices' => array(
        'units' => array('px', 'em')
    ),
    'default' => array(
        'style' => 'none',
        'top' => 0,
        'bottom' => 0,
        'left' => 0,
        'right' => 0,
        'color' => '',
        'unit' => 'px'
    ),
    'output' => array(
        array(
            'element' => '#sidebar .widget'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'settings' => 'widgets_box_shadow',
    'type' => 'box-shadow',
    'label' => esc_html__('Widgets box shadow', 'envo-extra'),
    'section' => 'main_sidebar',
    'transport' => 'auto',
    'default' => array(
        'v_offset' => 0,
        'h_offset' => 0,
        'spread' => 0,
        'blur' => 0,
        'color' => ''
    ),
    'output' => array(
        array(
            'element' => '#sidebar .widget'
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'widgets_spacing',
    'label' => esc_attr__('Widgets spacing', 'envo-extra'),
    'section' => 'main_sidebar',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em', '%')
    ),
    'default' => array(
        'top' => '0',
        'right' => '0',
        'bottom' => '0',
        'left' => '0',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '#sidebar .widget',
        ),
    ),
));