<?php

if (!class_exists('Kirki')) {
    return;
}

Kirki::add_section('top_bar', array(
    'title' => esc_attr__('Top Bar', 'envo-extra'),
    'panel' => 'envo_theme_panel',
    'priority' => 5,
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'topmenu_typography',
    'label' => esc_attr__('Top bar font', 'envo-extra'),
    'section' => 'top_bar',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '12px',
        'variant' => '400',
        'letter-spacing' => '0px',
        'text-transform' => 'none',
        'color' => '',
	'line-height'    => '1.5',
        'word-spacing'     => '0px',
        'text-decoration' => 'none'
    ),
    'priority' => 20,
    'output' => array(
        array(
            'element' => '.top-bar-section',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'color',
    'settings' => 'top_bar_bg_color',
    'label' => esc_attr__('Top bar background', 'envo-extra'),
    'section' => 'top_bar',
    'default' => '',
    'transport' => 'auto',
    'priority' => 30,
    'output' => array(
        array(
            'element' => '.top-bar-section',
            'property' => 'background-color',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'multicolor',
    'settings' => 'top_bar_links_color',
    'label' => esc_attr__('Top bar links', 'envo-extra'),
    'section' => 'top_bar',
    'priority' => 40,
    'transport' => 'auto',
    'choices' => array(
        'link' => esc_attr__('Links', 'envo-extra'),
        'hover' => esc_attr__('Hover', 'envo-extra'),
    ),
    'default' => array(
        'color' => '',
        'link' => '',
        'hover' => '',
    ),
    'output' => array(
        array(
            'choice' => 'link',
            'element' => '.top-bar-section a',
            'property' => 'color',
        ),
        array(
            'choice' => 'hover',
            'element' => '.top-bar-section a:hover',
            'property' => 'color',
        ),
    ),
));

Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'top_bar_spacing',
    'label' => esc_attr__('Top bar spacing', 'envo-extra'),
    'section' => 'top_bar',
    'priority' => 50,
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em')
    ),
    'default' => array(
        'top' => '5px',
        'right' => '0px',
        'bottom' => '5px',
        'left' => '0px',
    ),
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '.top-bar-section',
        ),
    ),
));
