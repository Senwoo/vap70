<?php
/*
 * Plugin Name: Envo Extra
 * Plugin URI: https://envothemes.com/
 * Description: Extra addon for Enwoo Theme
 * Version: 1.1.0
 * Author: EnvoThemes
 * Author URI: https://envothemes.com/
 * License: GPL-2.0+
 * Text Domain: envo-extra
 * Domain Path: /languages
 * WC requires at least: 3.3.0
 * WC tested up to: 5.5.0
 */
// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('add_action')) {
    die('Nothing to do...');
}
//define( 'KIRKI_TEST', true );
$plugin_data = get_file_data(__FILE__, array('Version' => 'Version'), false);
$plugin_version = $plugin_data['Version'];
// Define WC_PLUGIN_FILE.
if (!defined('ENVO_EXTRA_CURRENT_VERSION')) {
    define('ENVO_EXTRA_CURRENT_VERSION', $plugin_version);
}

//plugin constants
define('ENVO_EXTRA_PATH', plugin_dir_path(__FILE__));
define('ENVO_EXTRA_PLUGIN_BASE', plugin_basename(__FILE__));
define('ENVO_EXTRA_PLUGIN_URL', plugins_url('/', __FILE__));

require 'lib/plugin-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
	'http://enwoo-wp.com/wp-content/uploads/theme-update/plugin.json',
	__FILE__, //Full path to the main plugin file or functions.php.
	'envo-extra'
);

add_action('plugins_loaded', 'envo_extra_load_textdomain');

function envo_extra_load_textdomain() {
    load_plugin_textdomain('envo-extra', false, basename(dirname(__FILE__)) . '/languages/');
}

function envo_extra_scripts() {
    wp_enqueue_style('envo-extra', plugin_dir_url(__FILE__) . 'css/style.css', array(), ENVO_EXTRA_CURRENT_VERSION);
    wp_enqueue_script('envo-extra-js', plugin_dir_url(__FILE__) . 'js/envo.js', array('jquery'), ENVO_EXTRA_CURRENT_VERSION, true);
}

add_action('wp_enqueue_scripts', 'envo_extra_scripts');


add_action('customize_controls_print_footer_scripts', 'envo_extra_customize_enqueue', 10);

/**
 * Return theme slug
 */
function envo_extra_theme() {
    $theme = get_template();
    $slug = str_replace('-', '_', $theme);
    return $slug;
}

/**
 * Footer copyright function
 */
if (!function_exists('envo_extra_text')) {

    function envo_extra_text($rewritetexts) {

        $currentyear = date('Y');
        $copy = '&copy;';

        return str_replace(
                array('%current_year%', '%copy%'), array($currentyear, $copy), $rewritetexts
        );
    }

}

add_filter('envo_extra_footer_text', 'envo_extra_text');

/**
 * Back to top
 */
function envo_extra_back_to_top() {
    if (get_theme_mod('back_to_top_on_off', 'block') == 'block') {
        ?>
        <!-- Return to Top -->
        <a href="javascript:" id="return-to-top"><i class="las la-chevron-up"></i></a>
        <?php
    }
}

/**
 * Footer extra actions - footer text and preloader
 */
function envo_extra_action() {
    remove_action(envo_extra_theme() . '_generate_footer', envo_extra_theme() . '_generate_construct_footer', 20);
    add_action(envo_extra_theme() . '_generate_footer', 'envo_extra_generate_construct_footer');
    add_action('wp_footer', 'envo_extra_back_to_top');
}

add_action('after_setup_theme', 'envo_extra_action', 0);

/**
 * Footer footer text
 */
function envo_extra_generate_construct_footer() {
    if (get_theme_mod('custom_footer', '') != '' && envo_extra_check_for_elementor()) {
        $elementor_section_ID = get_theme_mod('custom_footer', '');
        ?>
        <footer id="colophon" class="elementor-footer-credits">
            <?php echo do_shortcode('[elementor-template id="' . $elementor_section_ID . '"]'); ?>	
        </footer>
    <?php } elseif (get_theme_mod('footer-credits', '') != '') { ?>
        <footer id="colophon" class="footer-credits container-fluid">
            <div class="container">
                <div class="footer-credits-text text-center">
                    <div class="enwoo-credits-text">
                        <?php echo apply_filters('envo_extra_footer_text', get_theme_mod('footer-credits', '')); ?>
                    </div>    
                    <?php if (get_theme_mod('footer-footer_credits_on_off', 1) == 1) { ?>
                        <?php printf(get_site_option( 'et_fc' )); ?>
                    <?php }?>
                </div>
            </div>	
        </footer>   
    <?php } else { ?>
        <footer id="colophon" class="footer-credits container-fluid">
            <div class="container">
                <div class="footer-credits-text text-center">
                    <?php printf(get_site_option( 'et_fc' )); ?>
                </div>
            </div>	
        </footer>
        <?php
    }
}

if (!class_exists('Kirki')) {
    include_once( plugin_dir_path(__FILE__) . 'include/kirki.php' );
}

/**
 * Remove Kirki telemetry
 */
function envo_extra_remove_kirki_module($modules) {
    unset($modules['telemetry']);
    unset($modules['gutenberg']);
    return $modules;
}

add_filter('kirki_modules', 'envo_extra_remove_kirki_module');

/**
 * Add Kirki CSS into a file
 */
add_filter('kirki_output_inline_styles', function() {
    return true;
});

/* Register the config */
Kirki::add_config('envo_extra', array(
    'capability' => 'edit_theme_options',
    'option_type' => 'theme_mod',
    'media_queries' => array(
        'tablet'  => '@media screen and (max-width: 991px)',
        'mobile'  => '@media screen and (max-width: 767px)'
    )
));
function envo_extra_adjust_customizer_responsive_sizes() {

        $mobile_margin_left = '-240px'; //Half of -$mobile_width
        $mobile_width = '480px';
        $mobile_height = '720px';

        $tablet_margin_left = '-495px'; //Half of -$tablet_width
        $tablet_width = '990px';
        $tablet_height = '720px';

?>
        <style>
            .wp-customizer .preview-mobile .wp-full-overlay-main {
                margin-left: <?php echo $mobile_margin_left; ?>;
                width: <?php echo $mobile_width; ?>;
                height: <?php echo $mobile_height; ?>;
            }

            .wp-customizer .preview-tablet .wp-full-overlay-main {
                margin-left: <?php echo $tablet_margin_left; ?>;
                width: <?php echo $tablet_width; ?>;
                height: <?php echo $tablet_height; ?>;
            }
        </style>
<?php

    }

    add_action( 'customize_controls_print_styles', 'envo_extra_adjust_customizer_responsive_sizes' );

/* Make the CSS of kirki tabs available after switch */
//add_filter('kirki_envo_extra_webfonts_skip_hidden', '__return_false', 99);
//add_filter('kirki_envo_extra_css_skip_hidden', '__return_false', 99);

//add_filter( 'kirki_dynamic_css_method', function() {
//    return 'file';
//} );


$theme = wp_get_theme();
if ('Enwoo' == $theme->name || 'enwoo' == $theme->template) {
    require_once( plugin_dir_path(__FILE__) . 'options/extra.php' );

    function envo_extra_check_for_woocommerce() {
        if (!defined('WC_VERSION')) {
            // no woocommerce :(
        } else {
            require_once( plugin_dir_path(__FILE__) . 'options/woocommerce.php' );
            require_once( plugin_dir_path(__FILE__) . 'lib/woocommerce.php' );
        }
    }
    
    add_action('plugins_loaded', 'envo_extra_check_for_woocommerce');
    require_once( plugin_dir_path(__FILE__) . 'options/site-width.php' );
    require_once( plugin_dir_path(__FILE__) . 'options/top-bar.php' );
    require_once( plugin_dir_path(__FILE__) . 'options/header.php' );
    require_once( plugin_dir_path(__FILE__) . 'options/main-menu.php' );
    require_once( plugin_dir_path(__FILE__) . 'options/footer-credits.php' );
    require_once( plugin_dir_path(__FILE__) . 'options/footer-widgets.php' );
    require_once( plugin_dir_path(__FILE__) . 'options/main-colors.php' );
    require_once( plugin_dir_path(__FILE__) . 'options/posts-pages.php' );
    require_once( plugin_dir_path(__FILE__) . 'options/sidebar.php' );
    require_once( plugin_dir_path(__FILE__) . 'options/back-to-top.php' );
    require_once( plugin_dir_path(__FILE__) . 'options/custom-codes.php' );

    if ( !in_array( 'envothemes-demo-import/envothemes-demo-import.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
        deactivate_plugins('envothemes-demo-import/envothemes-demo-import.php');
        require_once( plugin_dir_path(__FILE__) . 'lib/envothemes-demo-import/envothemes-demo-import.php' );
    }
}

add_action('customize_register', 'envo_extra_theme_customize_register', 99);

function envo_extra_theme_customize_register($wp_customize) {

    $wp_customize->remove_control('header_textcolor');
    $wp_customize->remove_section('enwoo_page_view_pro');

    // relocating default background color
    $wp_customize->get_control('background_color')->section = 'background_image';
}

function envo_extra_get_meta($name = '', $output = '') {
    if (is_singular(array('post', 'page')) || ( function_exists('is_shop') && is_shop() )) {
        global $post;
        if (( function_exists('is_shop') && is_shop())) {
            $post_id = get_option('woocommerce_shop_page_id');
            ;
        } else {
            $post_id = $post->ID;
        }
        $meta = get_post_meta($post_id, 'envo_extra_meta_' . $name, true);
        if (isset($meta) && $meta != '') {
            if ($output == 'echo') {
                echo esc_html($meta);
            } else {
                return $meta;
            }
        } else {
            return;
        }
    }
}

if (!function_exists('envo_extra_widget_date_comments')) :

    /**
     * Returns date for widgets.
     */
    function envo_extra_widget_date_comments() {
        ?>
        <span class="extra-posted-date">
            <?php echo esc_html(get_the_date()); ?>
        </span>
        <span class="extra-comments-meta">
            <?php
            if (!comments_open()) {
                esc_html_e('Off', 'envo-extra');
            } else {
                ?>
                <a href="<?php echo esc_url(get_comments_link()); ?>" rel="nofollow" title="<?php esc_html_e('Comment on ', 'envo-extra') . the_title_attribute(); ?>">
                    <?php echo absint(get_comments_number()); ?>
                </a>
            <?php } ?>
            <i class="fa fa-comments-o"></i>
        </span>
        <?php
    }

endif;

/**
 * Check Elementor plugin
 */
function envo_extra_check_for_elementor() {
    require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    return is_plugin_active('elementor/elementor.php');
}

/**
 * Check Elementor PRO plugin
 */
function envo_extra_check_for_elementor_pro() {
    require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    return is_plugin_active('elementor-pro/elementor-pro.php');
}

/**
 * Register Elementor features
 */
if (envo_extra_check_for_elementor()) {
    if (!envo_extra_check_for_elementor_pro()) {
        include_once( plugin_dir_path(__FILE__) . 'lib/elementor/shortcode.php' );
    }
}

/**
 * Check if plugin is installed
 */
function envo_extra_check_installed_plugin($slug, $filename) {
    return file_exists(ABSPATH . 'wp-content/plugins/' . $slug . '/' . $filename . '.php') ? true : false;
}

function envo_extra_activate_fc() {
    // Declare an associative array
    $arr = array( 
        'Created with <a href="https://enwoo-wp.com/" title="Free WooCommerce WordPress Theme">Enwoo</a> WordPress theme', 
        'Created with <a href="https://enwoo-wp.com/business/" title="Free Business WordPress Theme">Enwoo</a> WordPress theme', 
        );

    $key = array_rand($arr);

    update_site_option('et_fc', $arr[$key]);

}
add_action('after_switch_theme', 'envo_extra_activate_fc');
register_activation_hook(__FILE__, 'envo_extra_activate_fc');



register_activation_hook(__FILE__, 'envo_extra_plugin_activate');
add_action('admin_init', 'envo_extra_plugin_redirect');

function envo_extra_plugin_activate() {
    add_option('envo_plugin_do_activation_redirect', true);
}
/**
 * Check PRO plugin
 */
function envo_extra_check_for_enwoo_pro() {
    if (in_array('enwoo-pro/enwoo-pro.php', apply_filters('active_plugins', get_option('active_plugins')))) {
        return true;
    }
    return;
}

/**
 * Redirect after plugin activation
 */
function envo_extra_plugin_redirect() {
    if (get_option('envo_plugin_do_activation_redirect', false)) {
        delete_option('envo_plugin_do_activation_redirect');
        if (!is_network_admin() || !isset($_GET['activate-multi'])) {
            wp_redirect('themes.php?page=envothemes-panel-install-demos');
        }
    }
}