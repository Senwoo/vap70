<?php

if (!class_exists('Kirki')) {
    return;
}

Kirki::add_section('back_to_top', array(
    'title' => esc_attr__('Back to top', 'envo-extra'),
    'panel' => 'envo_theme_panel',
    'priority' => 80,
));

/**
 * Header cart icon
 */
Kirki::add_field('envo_extra', array(
    'type' => 'radio-buttonset',
    'label' => esc_html__('Back to top button', 'envo-extra'),
    'section' => 'back_to_top',
    'settings' => 'back_to_top_on_off',
    'default' => 'block',
    'transport' => 'auto',
    'choices' => array(
        'block' => esc_html__('On', 'envo-extra'),
        'none' => esc_html__('Off', 'envo-extra'),
    )
));
Kirki::add_field('envo_extra', array(
    'type' => 'multicolor',
    'settings' => 'back_to_top_color',
    'label' => esc_attr__('Colors', 'envo-extra'),
    'section' => 'back_to_top',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'color' => esc_attr__('Color', 'envo-extra'),
        'background' => esc_attr__('Background', 'envo-extra'),
        'color-hover' => esc_attr__('Color hover', 'envo-extra'),
        'background-hover' => esc_attr__('Background hover', 'envo-extra'),
    ),
    'default' => array(
        'color' => '',
        'background' => '',
        'color-hover' => '',
        'background-hover' => '',
    ),
    'output' => array(
        array(
            'choice' => 'color',
            'element' => '#return-to-top i',
            'property' => 'color',
        ),
        array(
            'choice' => 'background',
            'element' => '#return-to-top',
            'property' => 'background-color',
        ),
        array(
            'choice' => 'color-hover',
            'element' => '#return-to-top:hover i',
            'property' => 'color',
        ),
        array(
            'choice' => 'background-hover',
            'element' => '#return-to-top:hover',
            'property' => 'background-color',
        ),
    ),
    'active_callback' => array(
        array(
            'setting' => 'back_to_top_on_off',
            'operator' => '==',
            'value' => 'block',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'slider-advanced',
    'settings' => 'back_to_top_pos_left',
    'label' => esc_attr__('Position from right', 'envo-extra'),
    'section' => 'back_to_top',
    'default' => 1,
    'priority' => 10,
    'transport' => 'auto',
    'use_media_queries' => true,
    'choices' => array(
        'units' => array(
            '%' => array(
                'min' => 1,
                'max' => 100,
                'step' => 1
            ),
            'px' => array(
                'min' => 1,
                'max' => 500,
                'step' => 1
            ),
            'em' => array(
                'min' => 1,
                'max' => 2,
                'step' => .1
            )
        ),
    ),
    'output' => array(
        array(
            'element' => '#return-to-top',
            'property' => 'right',
            'units' => '%',
        ),
        array(
            'element' => '.rtl #return-to-top',
            'property' => 'left',
            'units' => '%',
        ),
    ),
    'active_callback' => array(
        array(
            'setting' => 'back_to_top_on_off',
            'operator' => '==',
            'value' => 'block',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'slider-advanced',
    'settings' => 'back_to_top_pos_right',
    'label' => esc_attr__('Position from bottom', 'envo-extra'),
    'section' => 'back_to_top',
    'default' => 1,
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'units' => array(
            '%' => array(
                'min' => 1,
                'max' => 100,
                'step' => 1
            ),
            'px' => array(
                'min' => 1,
                'max' => 500,
                'step' => 1
            ),
            'em' => array(
                'min' => 1,
                'max' => 2,
                'step' => .1
            )
        ),
    ),
    'output' => array(
        array(
            'element' => '#return-to-top',
            'property' => 'bottom',
            'units' => '%',
        ),
    ),
    'active_callback' => array(
        array(
            'setting' => 'back_to_top_on_off',
            'operator' => '==',
            'value' => 'block',
        ),
    ),
));
