<?php

if (!class_exists('Kirki')) {
    return;
}

Kirki::add_section('footer_credits', array(
    'title' => esc_attr__('Copyright (Footer Credits)', 'envo-extra'),
    'panel' => 'envo_theme_panel',
    'priority' => 50,
));

Kirki::add_field('envo_extra', array(
    'type' => 'editor',
    'settings' => 'footer-credits',
    'label' => __('Footer credits', 'envo-extra'),
    'description' => __('HTML is allowed.<br/> Use <code>%current_year%</code> to update year automatically.<br/> Use <code>%copy%</code> to include copyright symbol.', 'envo-extra'),
    'section' => 'footer_credits',
    'transport' => 'postMessage',
    'js_vars' => array(
        array(
            'element' => '.enwoo-credits-text',
            'function' => 'html',
        ),
    ),
    'default' => '',
    'priority' => 10,
));
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'footer-credits-font',
    'label' => esc_attr__('Font', 'envo-extra'),
    'section' => 'footer_credits',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'variant' => '400',
        'letter-spacing' => '0px',
        'font-size' => '',
        'line-height' => '',
        'text-transform' => 'none',
        'word-spacing' => '0px',
        'text-align' => 'none',
        'margin-top' => '5px',
        'margin-bottom' => '5px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.footer-credits-text',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'color',
    'settings' => 'copyright_bg_color',
    'label' => esc_attr__('Copyright background', 'envo-extra'),
    'section' => 'footer_credits',
    'default' => '',
    'transport' => 'auto',
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.footer-credits',
            'property' => 'background-color',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'multicolor',
    'settings' => 'copyright_links_color',
    'label' => esc_attr__('Copyright text colors', 'envo-extra'),
    'section' => 'footer_credits',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'color' => esc_attr__('Color', 'envo-extra'),
        'link' => esc_attr__('Links', 'envo-extra'),
        'hover' => esc_attr__('Hover', 'envo-extra'),
    ),
    'default' => array(
        'color' => '',
        'link' => '',
        'hover' => '',
    ),
    'output' => array(
        array(
            'choice' => 'color',
            'element' => '.footer-credits, .footer-credits-text',
            'property' => 'color',
        ),
        array(
            'choice' => 'link',
            'element' => '.footer-credits a',
            'property' => 'color',
        ),
        array(
            'choice' => 'hover',
            'element' => '.footer-credits a:hover',
            'property' => 'color',
        ),
    ),
));

Kirki::add_field('envo_extra', array(
    'type' => 'spacing-advanced',
    'settings' => 'footer_credits_spacing',
    'label' => esc_attr__('Copyright spacing', 'envo-extra'),
    'section' => 'footer_credits',
    'choices' => array(
        'use_media_queries' => true,
        'units' => array('px', 'em', '%')
    ),
    'default' => array(
        'top' => '20',
        'right' => '0',
        'bottom' => '20',
        'left' => '0',
    ),
    'transport' => 'auto',
    'output' => array(
        array(
            'property' => 'padding',
            'element' => '.footer-credits-text',
        ),
    ),
));
