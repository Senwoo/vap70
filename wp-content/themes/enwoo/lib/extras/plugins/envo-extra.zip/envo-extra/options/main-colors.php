<?php

if (!class_exists('Kirki')) {
    return;
}

Kirki::add_panel('envo_theme_panel', array(
    'priority' => 1,
    'title' => esc_attr__('Theme Options', 'envo-extra'),
));

Kirki::add_section('main_colors_section', array(
    'title' => esc_attr__('Content colors and typography', 'envo-extra'),
    'panel' => 'envo_theme_panel',
    'priority' => 20,
));

/**
 * Colors
 */
Kirki::add_field('envo_extra', array(
    'type' => 'typography-advanced',
    'settings' => 'main_typography',
    'label' => esc_attr__('Site font', 'envo-extra'),
    'section' => 'main_colors_section',
    'transport' => 'auto',
    'choices' => array(
        'use_media_queries' => true,
        'fonts' => envo_extra_fonts(),
    ),
    'default' => array(
        'font-family' => '',
        'font-size' => '15px',
        'variant' => '400',
        'line-height' => '1.6',
        'letter-spacing' => '0px',
        'color' => '',
        'word-spacing'     => '0px',
    ),
    'priority' => 10,
    'output' => array(
        array(
            'element' => 'body, nav.navigation.post-navigation a, .nav-subtitle',
        ),
        array(
            'choice' => 'color',
            'element' => '.comments-meta a, .the-product-share ul li a .product-share-text',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'color',
    'settings' => 'main_color_content_bg',
    'label' => esc_attr__('Background', 'envo-extra'),
    'section' => 'main_colors_section',
    'default' => '',
    'transport' => 'auto',
    'priority' => 10,
    'output' => array(
        array(
            'element' => '.main-container, #sidebar .widget-title h3, .container-fluid.archive-page-header, #product-nav > a',
            'property' => 'background-color',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'multicolor',
    'settings' => 'main_color_links',
    'label' => esc_attr__('Links', 'envo-extra'),
    'section' => 'main_colors_section',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'link' => esc_attr__('Color', 'envo-extra'),
        'hover' => esc_attr__('Hover', 'envo-extra'),
    ),
    'default' => array(
        'link' => '',
        'hover' => '',
    ),
    'output' => array(
        array(
            'choice' => 'link',
            'element' => 'a, .author-meta a, .tags-links a, .cat-links a, nav.navigation.pagination .nav-links a, .comments-meta a',
            'property' => 'color',
        ),
        array(
            'choice' => 'link',
            'element' => '.widget-title:before, nav.navigation.pagination .current:before',
            'property' => 'background-color',
        ),
        array(
            'choice' => 'link',
            'element' => 'nav.navigation.pagination .current:before',
            'property' => 'border-color',
        ),
        array(
            'choice' => 'hover',
            'element' => 'a:active, a:hover, a:focus, .tags-links a:hover, .cat-links a:hover, .comments-meta a:hover',
            'property' => 'color',
        ),
    ),
));
Kirki::add_field('envo_extra', array(
    'type' => 'multicolor',
    'settings' => 'main_color_buttons',
    'label' => esc_attr__('Buttons', 'envo-extra'),
    'section' => 'main_colors_section',
    'priority' => 10,
    'transport' => 'auto',
    'choices' => array(
        'color' => esc_attr__('Color', 'envo-extra'),
        'bg' => esc_attr__('Background', 'envo-extra'),
        'border' => esc_attr__('Border', 'envo-extra'),
    ),
    'default' => array(
        'color' => '',
        'bg' => '',
        'border' => '',
    ),
    'output' => array(
        array(
            'choice' => 'color',
            'element' => '.read-more-button a, #searchsubmit, .btn-default, input[type="submit"], input#submit, input#submit:hover, button, a.comment-reply-link, .btn-default:hover, input[type="submit"]:hover, button:hover, a.comment-reply-link:hover',
            'property' => 'color',
        ),
        array(
            'choice' => 'bg',
            'element' => '.read-more-button a, #searchsubmit, .btn-default, input[type="submit"], input#submit, input#submit:hover, button, a.comment-reply-link, .btn-default:hover, input[type="submit"]:hover, button:hover, a.comment-reply-link:hover',
            'property' => 'background-color',
        ),
        array(
            'choice' => 'border',
            'element' => '.read-more-button a, #searchsubmit, .btn-default, input[type="submit"], input#submit, input#submit:hover, button, a.comment-reply-link, .btn-default:hover, input[type="submit"]:hover, button:hover, a.comment-reply-link:hover',
            'property' => 'border-color',
        ),
    ),
));
